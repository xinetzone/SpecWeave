from . import chinese, english, chinese_mix
from . import cleaned_text_to_sequence
import copy

# The optional-language modules below load their OWN BERT tokenizers from
# HuggingFace at import time (e.g. french.py imports
# 'dbmdz/bert-base-french-europeana-cased'). We never use FR/SP/KR/JP, but on a
# host that can't reach HuggingFace those imports raise OSError, not just
# ImportError — so catch Exception, not ImportError, or `import melo.api` crashes
# on a language we don't even use. (melo_hf_bridge also forces HF offline so
# these fail fast as a cache miss rather than hanging on network retries.)
try:
    from . import japanese
except Exception:
    japanese = None
try:
    from . import korean
except Exception:
    korean = None
try:
    from . import french
except Exception:
    french = None
try:
    from . import spanish
except Exception:
    spanish = None

language_module_map = {"ZH": chinese, "EN": english, 'ZH_MIX_EN': chinese_mix}
if japanese:
    language_module_map["JP"] = japanese
if korean:
    language_module_map["KR"] = korean
if french:
    language_module_map["FR"] = french
if spanish:
    language_module_map["SP"] = spanish
    language_module_map["ES"] = spanish


def clean_text(text, language):
    language_module = language_module_map[language]
    norm_text = language_module.text_normalize(text)
    phones, tones, word2ph = language_module.g2p(norm_text)
    return norm_text, phones, tones, word2ph


def clean_text_bert(text, language, device=None):
    language_module = language_module_map[language]
    norm_text = language_module.text_normalize(text)
    phones, tones, word2ph = language_module.g2p(norm_text)

    word2ph_bak = copy.deepcopy(word2ph)
    for i in range(len(word2ph)):
        word2ph[i] = word2ph[i] * 2
    word2ph[0] += 1
    bert = language_module.get_bert_feature(norm_text, word2ph, device=device)

    return norm_text, phones, tones, word2ph_bak, bert


def text_to_sequence(text, language):
    norm_text, phones, tones, word2ph = clean_text(text, language)
    return cleaned_text_to_sequence(phones, tones, language)


if __name__ == "__main__":
    pass
