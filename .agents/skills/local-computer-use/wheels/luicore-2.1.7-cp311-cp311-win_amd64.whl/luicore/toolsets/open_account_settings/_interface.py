# coding: utf-8
from .tools import open_account_settings_page


async def tool_open_account_settings_page() -> bool:
    """
    Opens the account settings page.

    Args:
        None

    Returns:
        bool: True if the page was opened successfully, False otherwise.
    """
    return open_account_settings_page()
