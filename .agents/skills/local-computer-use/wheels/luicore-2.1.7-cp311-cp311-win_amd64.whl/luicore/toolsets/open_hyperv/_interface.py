# coding: utf-8
from .tools import open_hyperv_setting


async def tool_open_hyperv_setting() -> bool:
    """
    Opens the Windows Hyper-V virtual machine settings panel.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return open_hyperv_setting()
