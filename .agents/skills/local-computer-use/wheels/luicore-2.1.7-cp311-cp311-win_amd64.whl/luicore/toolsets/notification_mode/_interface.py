# coding: utf-8
from .tools import toggle_notification_mode


async def tool_toggle_notification_mode(enable: bool) -> bool:
    """
    Enables or disables the system notification mode.

    Args:
        enable (bool): True to enable system notifications, False to disable them.

    Returns:
        bool: True if successful, False otherwise.
    """
    return toggle_notification_mode(enable)


async def tool_toggle_do_not_disturb(enable: bool) -> bool:
    """
    Enables or disables Do Not Disturb mode.

    Args:
        enable (bool): True to enable Do Not Disturb mode, False to disable it.

    Returns:
        bool: True if successful, False otherwise.
    """
    return toggle_do_not_disturb_mode(enable)