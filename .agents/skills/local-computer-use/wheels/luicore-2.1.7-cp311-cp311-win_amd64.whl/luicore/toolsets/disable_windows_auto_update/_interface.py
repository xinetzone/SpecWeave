# coding: utf-8
from .tools import disable_windows_auto_update


async def tool_disable_windows_auto_update(weeks: int = -1) -> str:
    """
    Pauses Windows Update for a specified number of weeks.

    Args:
        weeks (int): Number of weeks to pause updates. -1 means no specific pause duration is set;
            values 1–5 indicate the corresponding number of weeks to pause.

    Returns:
        str: Result message indicating success or failure.
    """
    return disable_windows_auto_update(weeks)

async def tool_enable_windows_auto_update() -> str:
    """
    Restores Windows Update to its normal (enabled) state.

    Args:
        None

    Returns:
        str: Result message indicating success or failure.
    """
    return disable_windows_auto_update(0)
