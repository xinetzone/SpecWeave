# coding: utf-8
from .tools import set_auto_off_display_time, open_display_off_time_setting_panel


async def tool_set_auto_off_display_time(ac_time: int = -1, dc_time: int = -1) -> str:
    """
    Sets the display turn-off time in minutes for both AC power and battery power.

    Args:
        ac_time (int): Display turn-off time (in minutes) when running on AC power. 0 means never turn off. -1 means no change.
        dc_time (int): Display turn-off time (in minutes) when running on battery power. 0 means never turn off. -1 means no change.

    Returns:
        str: A description string of the current power state and configured display turn-off times.
    """
    return set_auto_off_display_time(ac_time, dc_time)


# async def tool_open_display_off_time_setting_panel() -> bool:
#     """
#     Opens the system's power and sleep settings panel so the user can manually adjust the display turn-off time.

#     Args:
#         None

#     Returns:
#         bool: True if the settings panel was opened successfully, False otherwise.
#     """
#     return open_display_off_time_setting_panel()
