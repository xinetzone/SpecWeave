# coding: utf-8
from .tools import open_on_screen_keyboard


async def tool_open_on_screen_keyboard() -> bool:
    """
    Opens the system on-screen keyboard if available.

    Args:
        None.

    Returns:
        bool: True if successful, False otherwise.
    """
    return open_on_screen_keyboard()
