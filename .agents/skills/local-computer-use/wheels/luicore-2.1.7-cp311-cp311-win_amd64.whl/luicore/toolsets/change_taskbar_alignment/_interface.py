# coding: utf-8
from .tools import set_taskbar_alignment


async def tool_set_taskbar_alignment(left_aligned: bool) -> str:
    """
    Sets the Windows taskbar alignment.

    Args:
        left_aligned (bool): True to set the taskbar to left-aligned, False to set the taskbar to center-aligned.

    Returns:
        str: A description of the result of the operation.
    """
    return set_taskbar_alignment(left_aligned)
