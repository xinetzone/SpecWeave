# coding: utf-8
from .tools import open_microsoft_store, restart_microsoft_store


async def tool_open_microsoft_store() -> bool:
    """
    Opens the Microsoft Store application.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return open_microsoft_store()

async def tool_restart_microsoft_store() -> bool:
    """
    Restarts the Microsoft Store application.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return restart_microsoft_store()