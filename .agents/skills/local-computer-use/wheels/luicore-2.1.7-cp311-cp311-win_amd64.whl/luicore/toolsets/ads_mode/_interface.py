# coding: utf-8
from .tools import toggle_ads_mode


async def tool_toggle_ads_mode(enable: bool) -> bool:
    """
    Enables or disables ads mode.

    Args:
        enable (bool): True to enable ads mode, False to disable ads mode.

    Returns:
        bool: True on success, False on failure.
    """
    return toggle_ads_mode(enable)