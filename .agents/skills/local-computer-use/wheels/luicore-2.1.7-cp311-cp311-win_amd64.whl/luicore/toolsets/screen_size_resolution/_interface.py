# coding: utf-8
from luicore.toolsets.screen_size_resolution.tools import (
    get_screen_info, set_screen_resolution, open_display_settings
)


async def tool_view_screen_info() -> list:
    """
    Gets information about connected displays including screen names, current resolutions,
    and available resolutions for the primary display.

    Returns:
        list: Structured screen info with names, current resolution, and available
        resolutions for each display.
    """
    return get_screen_info()


async def tool_set_screen_resolution(resolution: str, screen_index: int = 0) -> bool:
    """
    Sets the screen resolution to the specified values.

    Args:
        resolution (str): Resolution string, should be "width x height", like "1920x1080".
        screen_index (int): Screen index, 0 for primary display.

    Returns:
        bool: True if the screen resolution was set successfully, False otherwise.
    """
    return set_screen_resolution(resolution, screen_index)


async def tool_open_display_settings() -> bool:
    """
    Opens the Windows advanced display settings page.

    Returns:
        bool: True if the advanced display settings page was opened successfully,
        False otherwise.
    """
    return open_display_settings()
