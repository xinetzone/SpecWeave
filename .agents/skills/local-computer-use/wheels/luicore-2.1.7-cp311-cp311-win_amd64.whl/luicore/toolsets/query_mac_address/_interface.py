# coding: utf-8
from .tools import get_primary_mac_address


async def tool_get_primary_mac_address() -> list:
    """
    Queries the active network interface for its IP and MAC address.

    Args:
        None

    Returns:
        list: A structured payload containing MAC and related network information.
    """
    return get_primary_mac_address()
