# coding: utf-8
from .tools import open_event_viewer


async def tool_open_event_viewer() -> bool:
    """
    Opens the Windows Event Viewer.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return open_event_viewer()
