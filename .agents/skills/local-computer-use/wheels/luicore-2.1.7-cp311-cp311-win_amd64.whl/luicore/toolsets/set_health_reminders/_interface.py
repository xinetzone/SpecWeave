# coding: utf-8
from pydantic import Field
from .tools import set_drink_water_reminder, get_drink_water_reminder_settings, set_sedentary_reminder, get_sedentary_reminder_settings


from datetime import time
from typing import List, Literal

async def tool_set_drink_water_reminder(enabled: bool = Field(description="Whether to enable drink water reminder"),
    interval_minutes: int = Field(
        description="Reminder interval in minutes (e.g. 30, 45, 60)", ge=5, le=240
    ),
    active_start: time = Field(
        description="Daily start time for reminders (HH:MM, 24h)", example="09:00"
    ),
    active_end: time = Field(
        description="Daily end time for reminders (HH:MM, 24h)", example="21:00"
    ),) -> bool:
    """
    Name:
        Set drink water reminder
    Description:
        Enable or disable periodic drink water reminders, and configure reminder interval
        and active time range for each day.
    Args:
        enabled: Whether to enable drink water reminder
        interval_minutes: Reminder interval in minutes (5-240)
        active_start: Daily start time for reminders (HH:MM, 24h)
        active_end: Daily end time for reminders (HH:MM, 24h)
    Returns:
        True on success, False on failure.
    """
    return set_drink_water_reminder(enabled, interval_minutes, active_start, active_end)

async def tool_get_drink_water_reminder_settings() -> dict:
    """
    Name:
        Get drink water reminder settings
    Description:
        Get current drink water reminder configuration, including on/off status,
        interval and active time range.
    Returns:
        {
            "enabled": bool,
            "interval_minutes": int,
            "active_start": "HH:MM",
            "active_end": "HH:MM"
        }
    """
    return get_drink_water_reminder_settings()

async def tool_set_sedentary_reminder() -> bool:
    """
    Name:
        Set sedentary reminder
    Description:
        Enable or disable sedentary reminders, and configure interval, active weekdays
        and active time range.
    Returns:
        True on success, False on failure.
    """
    return set_sedentary_reminder()

async def tool_get_sedentary_reminder_settings() -> dict:
    """
    Name:
        Get sedentary reminder settings
    Description:
        Get current sedentary reminder configuration, including on/off status,
        interval, active weekdays and active time range.
    Returns:
        {
            "enabled": bool,
            "interval_minutes": int,
            "active_days": [ "Mon" | "Tue" | "Wed" | "Thu" | "Fri" | "Sat" | "Sun", ... ],
            "active_start": "HH:MM",
            "active_end": "HH:MM"
        }
    """
    return get_sedentary_reminder_settings()
