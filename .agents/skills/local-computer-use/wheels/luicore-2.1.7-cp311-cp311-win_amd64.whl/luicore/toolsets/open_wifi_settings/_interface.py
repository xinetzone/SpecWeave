# coding: utf-8
from .tools import open_wifi_settings


async def tool_open_wifi_settings() -> bool:
    """
    Opens the Wi-Fi settings.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return open_wifi_settings()
