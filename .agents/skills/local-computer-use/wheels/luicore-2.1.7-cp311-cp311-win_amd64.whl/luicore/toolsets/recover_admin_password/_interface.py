# coding: utf-8
from .tools import request_admin_password_reset


async def tool_request_admin_password_reset() -> bool:
    """
    Requests an administrator password reset.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return request_admin_password_reset()