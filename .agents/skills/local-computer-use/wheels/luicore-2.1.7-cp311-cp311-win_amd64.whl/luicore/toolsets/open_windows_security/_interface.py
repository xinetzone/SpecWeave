# coding: utf-8
from .tools import open_windows_security_home


async def tool_open_windows_security_home() -> bool:
    """
    Opens the Windows Security Center home page.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return open_windows_security_home()