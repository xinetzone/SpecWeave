# coding: utf-8
from .tools import open_personalization_settings


async def tool_open_personalization_settings() -> bool:
    """
    Opens the Windows personalization settings.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return open_personalization_settings()