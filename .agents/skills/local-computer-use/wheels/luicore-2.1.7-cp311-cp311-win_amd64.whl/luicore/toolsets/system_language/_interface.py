# coding: utf-8
from .tools import open_system_language_settings


async def tool_open_system_language_settings() -> None:
    """
    Opens/Checks/Changes/Sets the system language settings on the system.
    打开/查询/更改/设置系统语言设置

    Args:
        None

    Returns:
        None
    """
    open_system_language_settings()
    return None
