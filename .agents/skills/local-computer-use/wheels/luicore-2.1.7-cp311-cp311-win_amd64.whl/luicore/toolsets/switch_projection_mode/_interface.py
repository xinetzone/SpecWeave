# coding: utf-8
from .tools import set_projection_mode, open_projection_settings_panel


# 根据功能命名 MCP 服务


async def tool_set_projection_mode(mode: str = "仅电脑屏幕") -> bool:
    """
    Sets the Windows projection mode.

    Args:
        mode (str): The projection mode. Valid values: "仅电脑屏幕", "复制", "扩展", "仅第二屏幕".

    Returns:
        bool: True if successful, False otherwise.
    """
    return set_projection_mode(mode)


async def tool_open_projection_settings_panel() -> bool:
    """
    Opens the Windows projection mode settings panel.

    Returns:
        bool: True if successful, False otherwise.
    """
    return open_projection_settings_panel()
