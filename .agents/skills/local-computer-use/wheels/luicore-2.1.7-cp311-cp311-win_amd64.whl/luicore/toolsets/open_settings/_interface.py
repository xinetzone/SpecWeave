# coding: utf-8
from .tools import open_system_settings, open_apps_settings


async def tool_open_system_settings() -> bool:
    """
    Opens the Windows system settings page.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return open_system_settings()


async def tool_open_apps_settings() -> bool:
    """
    Opens the Windows Apps settings page.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return open_apps_settings()
