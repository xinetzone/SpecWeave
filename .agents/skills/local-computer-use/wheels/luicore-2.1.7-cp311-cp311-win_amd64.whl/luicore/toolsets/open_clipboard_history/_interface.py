# coding: utf-8
from .tools import open_clipboard_history


async def tool_open_clipboard_history() -> bool:
    """
    Opens the clipboard history on Windows.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return open_clipboard_history()
