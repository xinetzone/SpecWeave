# coding: utf-8
from pydantic import Field
from .tools import batch_add_watermark, preview_watermark


async def tool_batch_add_watermark(input_dir: str = Field(description="Directory containing images to watermark", default = ""),
    output_dir: str = Field(description="Directory to save watermarked images", default = ""),
    watermark_image: str = Field(description="Path to the watermark image (e.g., PNG with transparency)", default = ""),
    position: str = Field(
        description="Watermark position on the image. "
                    "Supported values: 'top-left', 'top-right', 'bottom-left', 'bottom-right', 'center'"
    , default = "center"),
    opacity: float = Field(
        description="Watermark opacity between 0.0 (fully transparent) and 1.0 (fully opaque)"
    , default = 0.5),
    scale: float = Field(
        description="Relative scale of the watermark compared to the base image width, "
                    "for example 0.2 means watermark width is 20% of the base image width"
    , default = 0.5),
    overwrite: bool = Field(
        description="Whether to overwrite existing files in the output directory if they already exist"
    , default = False),
    recursive: bool = Field(
        description="Whether to search for images recursively in subdirectories of input_dir"
    , default = True),
    image_patterns: str = Field(
        description="File name patterns to match images, separated by commas. "
                    "For example: '*.jpg,*.jpeg,*.png'"
    , default = "*.jpg,*.jpeg,*.png"),) -> bool:
    """
    Name:
        Batch add watermark to images
    Description:
        Add a watermark image to multiple images in a directory and save the processed images to the output directory.
        Supports positioning, opacity, and scaling of the watermark, and optional recursive search of input directory.
    Args:
        input_dir: Directory containing images to watermark.
        output_dir: Directory to save watermarked images.
        watermark_image: Path to the watermark image (e.g., PNG with transparency).
        position: Watermark position. Supported values: 'top-left', 'top-right', 'bottom-left', 'bottom-right', 'center'.
        opacity: Watermark opacity between 0.0 (fully transparent) and 1.0 (fully opaque).
        scale: Relative scale of the watermark compared to the base image width, e.g. 0.2 for 20%.
        overwrite: Whether to overwrite existing files in the output directory.
        recursive: Whether to search recursively in subdirectories of input_dir.
        image_patterns: File name patterns to match images, separated by commas.
    Returns:
        True on success, False on failure.
    """
    return batch_add_watermark(input_dir, output_dir, watermark_image, position, opacity, scale, overwrite, recursive, image_patterns)

async def tool_preview_watermark(image_path: str = Field(description="Path to a single image to generate a watermark preview for"),
    watermark_image: str = Field(description="Path to the watermark image (e.g., PNG with transparency)"),
    position: str = Field(
        description="Watermark position on the image. "
                    "Supported values: 'top-left', 'top-right', 'bottom-left', 'bottom-right', 'center'"
    ),
    opacity: float = Field(
        description="Watermark opacity between 0.0 (fully transparent) and 1.0 (fully opaque)"
    ),
    scale: float = Field(
        description="Relative scale of the watermark compared to the base image width, "
                    "for example 0.2 means watermark width is 20% of the base image width"
    ),
    output_path: str = Field(
        description="Path to save the preview image with watermark applied"
    ),) -> bool:
    """
    Name:
        Preview watermark on a single image
    Description:
        Apply the watermark settings to a single image and save the result as a preview image.
    Args:
        image_path: Path to the image to preview watermark on.
        watermark_image: Path to the watermark image (e.g., PNG with transparency).
        position: Watermark position. Supported values: 'top-left', 'top-right', 'bottom-left', 'bottom-right', 'center'.
        opacity: Watermark opacity between 0.0 (fully transparent) and 1.0 (fully opaque).
        scale: Relative scale of the watermark compared to the base image width, e.g. 0.2 for 20%.
        output_path: Path to save the preview image with watermark applied.
    Returns:
        True on success, False on failure.
    """
    return preview_watermark(image_path, watermark_image, position, opacity, scale, output_path)
