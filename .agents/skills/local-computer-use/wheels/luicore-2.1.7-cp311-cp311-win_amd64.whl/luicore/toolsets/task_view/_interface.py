# coding: utf-8
from .tools import open_task_view


async def tool_open_task_view() -> bool:
    """
    Opens the Task View.

    Args:
        None

    Returns:
        bool: True if the Task View was opened successfully, False otherwise.
    """
    return open_task_view()
