# coding: utf-8
from .tools import open_task_manager


async def tool_open_task_manager() -> bool:
    """
    Opens the Windows Task Manager to view running processes.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return open_task_manager()
