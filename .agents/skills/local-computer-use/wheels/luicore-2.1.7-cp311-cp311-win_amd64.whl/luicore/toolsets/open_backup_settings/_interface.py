# coding: utf-8
from .tools import open_backup_settings


async def tool_open_backup_settings() -> bool:
    """
    Opens the backup settings panel.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return open_backup_settings()