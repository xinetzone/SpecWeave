# coding: utf-8
from pydantic import Field
from .tools import convert_text_to_speech, list_voices, get_default_tts_settings, set_default_tts_settings


async def tool_convert_text_to_speech(text) -> str:
    """
    Name:
        Convert text to speech
    Description:
        Convert the given text to speech audio and return the output file path.
    Args:
        text: Text content to be converted to speech.
    """
    return convert_text_to_speech(text)

async def tool_list_voices(language: str = Field(
        default="",
        description="Optional language/locale filter (for example: en-US, zh-CN). If empty, return all voices."
    )) -> list[dict]:
    """
    Name:
        List available voices
    Description:
        List all available TTS voices, optionally filtered by language/locale.
    Args:
        language: Optional language/locale filter (for example: en-US, zh-CN). If empty, return all voices.
    Returns:
        A list of voice metadata objects. Each item should at least contain 'name' and 'language' fields.
    """
    return list_voices(language)

async def tool_get_default_tts_settings() -> dict:
    """
    Name:
        Get default TTS settings
    Description:
        Get the default configuration used for text-to-speech conversion.
    Returns:
        A dict containing default TTS settings such as language, voice_name, speaking_rate, pitch and audio_format.
    """
    return get_default_tts_settings()

async def tool_set_default_tts_settings(language: str = Field(
        default="",
        description="Default language/locale of the voice (for example: en-US, zh-CN). Empty string means keep current."
    ),
    voice_name: str = Field(
        default="",
        description="Default voice name or identifier. Empty string means keep current."
    ),
    speaking_rate: float = Field(
        default=0.0,
        description="Default speaking rate multiplier (> 0). Value <= 0 means keep current."
    ),
    pitch: float = Field(
        default=0.0,
        description="Default pitch adjustment. Special value (for example 9999) can be used to keep current."
    ),
    audio_format: str = Field(
        default="",
        description="Default output audio format (e.g. mp3, wav, ogg). Empty string means keep current."
    ),) -> bool:
    """
    Name:
        Set default TTS settings
    Description:
        Update the default configuration used for text-to-speech conversion.
    Args:
        language: Default language/locale of the voice (for example: en-US, zh-CN). Empty string means keep current.
        voice_name: Default voice name or identifier. Empty string means keep current.
        speaking_rate: Default speaking rate multiplier (> 0). Value <= 0 means keep current.
        pitch: Default pitch adjustment. Special value (for example 9999) can be used to keep current.
        audio_format: Default output audio format (e.g. mp3, wav, ogg). Empty string means keep current.
    Returns:
        True on success, False on failure.
    """
    return set_default_tts_settings(language, voice_name, speaking_rate, pitch, audio_format)
