# coding: utf-8
from .tools import set_taskbar_auto_hide, disable_taskbar_auto_hide, open_task_bar_settings_panel


async def tool_enable_taskbar_auto_hide() -> bool:
    """
    Enables the Windows taskbar to automatically hide when not in use.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return set_taskbar_auto_hide()

async def tool_disable_taskbar_auto_hide() -> bool:
    """
    Disables the Windows taskbar auto-hide behavior.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return disable_taskbar_auto_hide()

async def tool_open_task_bar_settings() -> bool:
    """
    Opens the Windows taskbar settings.
    Args:
        None
    Returns:
        bool: True if successful, False otherwise.
    """
    return open_task_bar_settings_panel()