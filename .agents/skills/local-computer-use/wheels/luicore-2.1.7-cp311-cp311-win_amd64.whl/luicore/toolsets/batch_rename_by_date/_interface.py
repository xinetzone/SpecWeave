# coding: utf-8
from pydantic import Field
from .tools import preview_rename_by_date, apply_rename_by_date, revert_last_rename_session


from typing import List


async def tool_preview_rename_by_date(directory: str = Field(description="Target directory to scan for files"),
    pattern: str = Field(
        description=(
            "Rename pattern, supports placeholders like "
            "{created}, {modified}, {index}, {stem}, {ext}"
        )
    ),
    recursive: bool = Field(
        default=False,
        description="Whether to scan subdirectories recursively",
    ),
    sort_by: str = Field(
        default="created",
        description="Sort key for indexing: 'created', 'modified', or 'name'",
    ),
    date_format: str = Field(
        default="%Y%m%d_%H%M%S",
        description=(
            "strftime compatible format string used for {created} and {modified} "
            "placeholders"
        ),
    ),
    include_patterns: List[str] = Field(
        default_factory=list,
        description="Optional glob patterns to include (e.g. ['*.jpg', '*.png'])",
    ),
    exclude_patterns: List[str] = Field(
        default_factory=list,
        description="Optional glob patterns to exclude (e.g. ['*.tmp', '*.bak'])",
    ),
    dry_run_limit: int = Field(
        default=100,
        description="Maximum number of files to include in the preview result",
    ),) -> List[dict]:
    """
    Name:
        Preview batch rename files by date
    Description:
        Scan a directory and generate a preview mapping of original filenames to
        new filenames based on file timestamps and a rename pattern. This does
        not modify the filesystem.
    Args:
        directory: Target directory to scan for files.
        pattern: Rename pattern using placeholders {created}, {modified},
                 {index}, {stem}, {ext}.
        recursive: Whether to scan subdirectories recursively.
        sort_by: Sort key used to assign {index}: 'created', 'modified', or 'name'.
        date_format: strftime-compatible format string for date placeholders.
        include_patterns: Optional list of glob patterns to include.
        exclude_patterns: Optional list of glob patterns to exclude.
        dry_run_limit: Maximum number of entries to return in the preview.
    Returns:
        A list of objects describing the planned renames:
        [
            {
                "original_path": "<full/original/path>",
                "new_path": "<full/new/path>",
                "conflict": false
            },
            ...
        ]
    """
    return preview_rename_by_date(directory, pattern, recursive, sort_by, date_format, include_patterns, exclude_patterns, dry_run_limit)

async def tool_apply_rename_by_date(directory: str = Field(description="Target directory to scan for files"),
    pattern: str = Field(
        description=(
            "Rename pattern, supports placeholders like "
            "{created}, {modified}, {index}, {stem}, {ext}"
        )
    ),
    recursive: bool = Field(
        default=False,
        description="Whether to scan subdirectories recursively",
    ),
    sort_by: str = Field(
        default="created",
        description="Sort key for indexing: 'created', 'modified', or 'name'",
    ),
    date_format: str = Field(
        default="%Y%m%d_%H%M%S",
        description=(
            "strftime compatible format string used for {created} and {modified} "
            "placeholders"
        ),
    ),
    include_patterns: List[str] = Field(
        default_factory=list,
        description="Optional glob patterns to include (e.g. ['*.jpg', '*.png'])",
    ),
    exclude_patterns: List[str] = Field(
        default_factory=list,
        description="Optional glob patterns to exclude (e.g. ['*.tmp', '*.bak'])",
    ),
    overwrite: bool = Field(
        default=False,
        description="Whether to overwrite files when name conflicts occur",
    ),
    commit_limit: int = Field(
        default=1000,
        description="Maximum number of files to rename in one operation",
    ),) -> dict:
    """
    Name:
        Apply batch rename files by date
    Description:
        Perform batch rename of files in a directory based on their timestamps
        and a rename pattern.
    Args:
        directory: Target directory to scan for files.
        pattern: Rename pattern using placeholders {created}, {modified},
                 {index}, {stem}, {ext}.
        recursive: Whether to scan subdirectories recursively.
        sort_by: Sort key used to assign {index}: 'created', 'modified', or 'name'.
        date_format: strftime-compatible format string for date placeholders.
        include_patterns: Optional list of glob patterns to include.
        exclude_patterns: Optional list of glob patterns to exclude.
        overwrite: Whether to overwrite existing files when conflicts occur.
        commit_limit: Maximum number of files to rename in one operation.
    Returns:
        A summary object:
        {
            "total_scanned": int,
            "total_renamed": int,
            "conflicts": [
                {
                    "original_path": "<full/original/path>",
                    "requested_path": "<full/new/path>",
                    "reason": "<conflict description>"
                },
                ...
            ],
            "errors": [
                {
                    "original_path": "<full/original/path>",
                    "error": "<error message>"
                },
                ...
            ]
        }
    """
    return apply_rename_by_date(directory, pattern, recursive, sort_by, date_format, include_patterns, exclude_patterns, overwrite, commit_limit)

async def tool_revert_last_rename_session(session_id: str = Field(
        description=(
            "Identifier of a previous rename session to revert. "
            "Returned from a successful tool_apply_rename_by_date call."
        )
    )) -> bool:
    """
    Name:
        Revert last batch rename session
    Description:
        Revert file renames performed in a previous batch rename session.
    Args:
        session_id: Identifier of the rename session to revert.
    Returns:
        True if the revert operation is scheduled/succeeded, False otherwise.
    """
    return revert_last_rename_session(session_id)
