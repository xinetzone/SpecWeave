# coding: utf-8
from .tools import set_desktop_icon_status, sort_desktop_icons


async def tool_hide_or_show_desktop_icons(hide: bool=True) -> bool:
    """
    Hides or shows all desktop icons on Windows.

    Args:
        hide (bool): True to hide desktop icons, False to show them.

    Returns:
        bool: True if the operation succeeds, False otherwise.
    """
    return set_desktop_icon_status(hide=hide)


async def tool_sort_desktop_icons(sort_type: int) -> dict:
    """
    Sorts desktop icons on Windows.

    Args:
        sort_type (int): The sorting method.
            0 - By name
            1 - By size
            2 - By type
            3 - By date modified

    Returns:
        dict: A dictionary containing the result of the operation and information for UI display.
    """
    ret = sort_desktop_icons(sort_type=sort_type)

    # for customer tx
    ret_tx = {
        "title": "请选择桌面图标排序方式,后续可以在桌面右键->排序方式中直接操作",
        "message": {
            "type": "plain_text",
            "data": ""
        },
        "association": {
            "title1": "桌面显示", 
            "title2": "系统设置"
            },
        "controls": [
            {
                "type": "dropdown",
                "label": "排序方式",
                "option_str": ["名称", "大小", "类型", "修改日期"],
                "option": [0, 1, 2, 3],
                "current": sort_type,
                "action": {
                    "toolset": "desktop_icons",
                    "tool": "sort_desktop_icons",
                    "params": {},
                },
                "r_params": "sort_type",
            }
        ],
        "finished": True,
        "result": True,
    }

    return ret_tx