# coding: utf-8
from .tools import list_installed_applications, uninstall_application, get_uninstall_status


async def tool_list_installed_applications() -> list[str]:
    """
    Gets a list of human-readable names of applications currently installed on the system.

    Args:
        None

    Returns:
        list[str]: A list of application display names.
    """
    return list_installed_applications()

async def tool_uninstall_application(application_name: str, silent: bool = False) -> bool:
    """
    Uninstalls the specified application from the system.

    Args:
        application_name (str): The display name of the application to uninstall.
        silent (bool): Whether to attempt a silent (no UI) uninstallation.

    Returns:
        bool: True if the uninstallation was started or completed successfully, False otherwise.
    """
    return uninstall_application(application_name, silent)

async def tool_get_uninstall_status(application_name: str) -> str:
    """
    Gets the latest known uninstall status for the specified application.

    Args:
        application_name (str): The display name of the application whose uninstall status is queried.

    Returns:
        str: A short status string such as "pending", "in_progress", "succeeded", or "failed".
    """
    return get_uninstall_status(application_name)
