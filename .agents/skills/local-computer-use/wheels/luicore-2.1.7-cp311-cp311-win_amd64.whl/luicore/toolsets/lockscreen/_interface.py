# coding: utf-8
from .tools import lock_screen


async def tool_lock_screen() -> bool:
    """
    Locks the computer screen.

    Returns:
        bool: True if the operation was successful, False otherwise.
    """
    return lock_screen()
