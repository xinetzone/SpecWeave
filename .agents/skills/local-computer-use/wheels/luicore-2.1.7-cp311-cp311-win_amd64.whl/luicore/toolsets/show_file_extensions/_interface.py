# coding: utf-8
from .tools import set_show_file_extensions


async def tool_set_show_file_extensions(show: bool) -> bool:
    """
    Sets whether to show file name extensions in Windows Explorer.

    Args:
        show (bool): True to show file extensions, False to hide them.

    Returns:
        bool: True if successful, False otherwise.
    """
    return set_show_file_extensions(show)
