# coding: utf-8
from .tools import open_mouse_style_color_setting


async def tool_open_mouse_style_color_setting() -> bool:
    """
    Opens the Windows mouse style and color settings page.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return open_mouse_style_color_setting()
