# coding: utf-8
from .tools import get_touchpad_enabled_status, get_touchpad_sensitivity, open_touchpad_settings, set_touchpad_sensitivity, enable_touchpad


async def tool_is_touchpad_enabled() -> int:
    """
    Checks if touchpad is enabled on the system.

    Args:
        None
    Returns:
        int: The raw touchpad enabled status (1 if enabled, 0 if disabled, <0 on error).
    """
    return get_touchpad_enabled_status()

async def tool_set_touchpad_status(enabled: bool) -> int:
    """
    Enables/Opens or disables/close touchpad on the system.
    打开触摸板

    Args:
        enabled (bool): True to enable touchpad, False to disable it.
    Returns:
        int: The raw touchpad enabled status before the toggle (<0 on error).
    """
    status = get_touchpad_enabled_status()
    if status < 0:
        return status

    enable_touchpad(enabled)
    return status

async def tool_open_touchpad_settings() -> None:
    """
    Opens the touchpad settings on the system.
    打开触摸板设置
    **This is to open settings instead of opening touchpad.**

    Args:
        None

    Returns:
        None
    """
    open_touchpad_settings()
    return None

async def tool_set_touchpad_sensitivity(sensitivity: int = -1) -> tuple[int, bool, int]:
    """
    Sets the touchpad sensitivity on the system.
    设置触摸板敏感度/灵敏度

    Args:
        sensitivity (int): The sensitivity level to set (0-3) or -1 to not change, default value is -1.
            -1: Not Changed
            0: Most sensitive, 最高敏感度
            1: High sensitivity, 高敏感度
            2: Medium sensitivity, 中等敏感度
            3: Low sensitivity, 低敏感度

    Returns:
        tuple[int, bool, int]: A tuple of (touchpad_enabled_status, set_ret, effective_sensitivity).
    """
    _sensitivity = {
        0: "Most sensitive",
        1: "High sensitivity",
        2: "Medium sensitivity",
        3: "Low sensitivity"
    }

    _data = {
        "status": "disabled",
        "result": False,
        "sensitivity": "unknown"
    }

    status = get_touchpad_enabled_status()
    if status < 0:
        return (status, False, -1)

    ret = set_touchpad_sensitivity(sensitivity)
    return (status, ret, sensitivity if ret else get_touchpad_sensitivity())


async def tool_get_touchpad_sensitivity() -> int:
    """
    Gets the current touchpad sensitivity on the system.
    获取当前触摸板敏感度/灵敏度

    Args:
        None

    Returns:
        int: The current touchpad sensitivity (0-3), or <0 on error.
    """
    return get_touchpad_sensitivity()
