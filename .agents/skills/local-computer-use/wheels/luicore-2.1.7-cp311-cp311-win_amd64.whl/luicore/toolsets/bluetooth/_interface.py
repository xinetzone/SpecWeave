# coding: utf-8
from .tools import is_bluetooth_enabled, open_bluetooth_settings, set_bluetooth_status


async def tool_is_bluetooth_enabled() -> bool:
    """
    Checks if Bluetooth is enabled on the system.

    Args:
        None
    Returns:
        bool: True if Bluetooth is enabled, False otherwise.
    """
    return is_bluetooth_enabled()

async def tool_set_bluetooth_status(enabled: bool) -> bool:
    """
    Enables/Opens or disables/close Bluetooth on the system.
    打开蓝牙

    Args:
        enabled (bool): True to enable Bluetooth, False to disable it.
    Returns:
        bool: True if the operation was successful, False otherwise.
    """
    return set_bluetooth_status(enabled)

async def tool_open_bluetooth_settings() -> None:
    """
    Opens the Bluetooth settings on the system.
    打开蓝牙设置
    **This is to open settings instead of opening Bluetooth.**

    Args:
        None

    Returns:
        None
    """
    open_bluetooth_settings()
    return None