# coding: utf-8
from .tools import open_computer_management_panel


async def tool_open_computer_management() -> bool:
    """
    Opens the Windows Computer Management panel.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return open_computer_management_panel()