# coding: utf-8
from .tools import open_display_scaling_settings, set_display_scaling, get_current_display_scaling


async def tool_open_display_scaling_settings() -> bool:
    """
    Opens the Windows display scaling settings panel
    Users can then change the display scaling level and make texts and apps larger or smaller.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    open_display_scaling_settings()
    return True

async def tool_set_display_scaling(scaling: int = 100) -> bool:
    """
    set display scaling to an absolute level between 100 and 350 percent.

    Args:
        scaling: The desired display scaling level (100-350). Default is 100.

    Returns:
        bool: True if successful, False otherwise.
    """
    return set_display_scaling(scaling)

async def tool_get_current_display_scaling() -> int:
    """
    Get current display scaling level.

    Args:
        None

    Returns:
        int: The current display scaling level as a percentage (e.g., 100, 125, 150).
    """
    return get_current_display_scaling()