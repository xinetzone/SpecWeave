# coding: utf-8
from .tools import open_pictures_library, open_snipping_tool


async def tool_open_pictures_library() -> bool:
    """
    Opens the pictures library.
    打开图片库

    Args:
        None

    Returns:
        bool: True if the operation was successful, False otherwise.
    """
    return open_pictures_library()


async def tool_open_snipping_tool() -> bool:
    """
    Opens the snipping tool.
    打开截图工具

    Args:
        None

    Returns:
        bool: True if the operation was successful, False otherwise.
    """
    return open_snipping_tool()
