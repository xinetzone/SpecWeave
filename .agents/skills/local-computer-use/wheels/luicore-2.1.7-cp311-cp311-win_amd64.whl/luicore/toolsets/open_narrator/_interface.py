# coding: utf-8
from .tools import open_narrator_settings_panel


async def tool_open_narrator_settings_panel() -> bool:
    """
    Opens the Windows Narrator settings panel.

    Args:
        None

    Returns:
        bool: True if the panel was opened successfully, False otherwise.
    """
    return open_narrator_settings_panel()