# coding: utf-8
from .tools import open_calculator


async def tool_open_calculator() -> bool:
    """
    Opens the system calculator.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return open_calculator()
