# coding: utf-8
from .tools import open_input_method_setting


async def tool_open_input_method_setting() -> bool:
    """
    Opens the Windows input method settings page.
    User can manage (e.g. add, delete or switch) input methods there.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return open_input_method_setting()