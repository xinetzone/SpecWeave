# coding: utf-8
from .tools import get_os_type


async def tool_get_os_type() -> str:
    """
    Queries the operating system type.

    Args:
        None.

    Returns:
        str: A string representing the operating system type, such as "Windows", "Linux", or "macOS".
    """
    return get_os_type()
