# coding: utf-8
from .tools import get_basic_system_info, get_pc_bios_info


async def tool_get_basic_system_info() -> list:
    """
    Gets basic operating system information.
    获取基本的电脑操作系统信息，包括操作系统名称、版本和架构。

    Args:
        None

    Returns:
        list: Basic system information including OS name, version, and architecture.
    """
    return get_basic_system_info()


async def tool_get_pc_bios_info() -> str:
    """
    Gets PC BIOS information.
    获取电脑BIOS信息，包括BIOS版本和发布日期。

    Args:
        None

    Returns:
        str: BIOS information including BIOS version and release date.
    """
    return get_pc_bios_info()