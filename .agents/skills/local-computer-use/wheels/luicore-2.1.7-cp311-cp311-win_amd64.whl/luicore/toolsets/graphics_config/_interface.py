# coding: utf-8
from .tools import set_gpu_memory_limit

async def tool_set_gpu_memory_limit(limit: int) -> bool:
    """
    Sets the GPU memory limit to a specified percentage.

    Args:
        limit: The desired GPU memory limit percentage (13-87), default value is 57.

    Returns:
        bool: True if successful, False otherwise.
    """
    return set_gpu_memory_limit(limit)
    