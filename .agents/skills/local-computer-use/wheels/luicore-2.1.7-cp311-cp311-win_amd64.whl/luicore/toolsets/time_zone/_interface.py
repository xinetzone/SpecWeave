# coding: utf-8
from .tools import get_current_time_zone_display_name, set_time_zone_by_region


async def tool_get_current_time_zone() -> str:
    """
    Gets the current time zone of the system.

    Args:
        None

    Returns:
        str: The current time zone, for example "(UTC+08:00) 北京，重庆，香港特别行政区，乌鲁木齐".
    """
    return get_current_time_zone_display_name()

async def tool_set_time_zone(region_name: str = "北京") -> bool:
    """
    Sets the time zone of the system based on the provided region name.

    Args:
        region_name (str): The name of the region to set the time zone for. Default is "北京".

    Returns:
        bool: True if the time zone was successfully set, False otherwise.
    """
    return set_time_zone_by_region(region_name)
