# coding: utf-8
from pydantic import Field
from .tools import translate_text, translate_file, list_supported_languages


async def tool_translate_text(text: str = Field(description="Source text to be translated"),
    source_language: str = Field(
        description="Source language code or name, e.g. 'en', 'zh-CN', 'auto' for auto-detection"
    ),
    target_language: str = Field(
        description="Target language code or name, e.g. 'en', 'zh-CN'"
    ),) -> str:
    """
    Name:
        Translate text
    Description:
        Translate the given text from source_language to target_language and
        return the translated result as a single string.
    Args:
        text: Source text to be translated.
        source_language: Source language code or name. Use 'auto' for auto-detection if supported.
        target_language: Target language code or name.
    Returns:
        Translated text.
    """
    return translate_text(text, source_language, target_language)

async def tool_translate_file(file_path: str = Field(description="Path of the document file to be translated"),
    source_language: str = Field(
        description="Source language code or name, e.g. 'en', 'zh-CN', 'auto' for auto-detection"
    ),
    target_language: str = Field(
        description="Target language code or name, e.g. 'en', 'zh-CN'"
    ),
    output_path: str = Field(
        description="Path to save the translated file; if empty, use the same directory as input",
        default="",
    ),) -> str:
    """
    Name:
        Translate document file
    Description:
        Translate the content of the specified document file from source_language to
        target_language and optionally save it as a new file.
    Args:
        file_path: Full path of the input document file.
        source_language: Source language code or name. Use 'auto' for auto-detection if supported.
        target_language: Target language code or name.
        output_path: Full path for the translated output file. If empty, a default
            path will be generated in the same directory as the input file.
    Returns:
        The full path of the translated output file.
    """
    return translate_file(file_path, source_language, target_language, output_path)

async def tool_list_supported_languages() -> list[str]:
    """
    Name:
        List supported languages
    Description:
        List all language codes or names supported by the translation engine.
    Returns:
        A list of supported language codes or names (e.g. ['en', 'zh-CN', 'ja']).
    """
    return list_supported_languages()
