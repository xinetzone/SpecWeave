# coding: utf-8
from pydantic import Field
from .tools import generate_ppt_from_template, preview_ppt_placeholders, validate_ppt_generation_request


async def tool_generate_ppt_from_template(template_path: str, output_path: str, placeholders: dict) -> bool:
    """
    Name:
        Generate PowerPoint from template
    Description:
        Generate a new PowerPoint file based on a template file. The template may contain text markers
        or structured placeholders which are replaced by values from the 'placeholders' dictionary.
        Returns True on success, False on failure.
    Args:
        template_path: Full file path of the PowerPoint template (.pptx)
        output_path: Full file path for the generated PowerPoint (.pptx)
        placeholders: Dictionary of placeholder values used to fill the template
    Returns:
        True on success, False on failure.
    """
    return generate_ppt_from_template(template_path, output_path, placeholders)

async def tool_preview_ppt_placeholders(template_path: str = Field(description="Full file path of the PowerPoint template (.pptx)")) -> list[str]:
    """
    Name:
        Preview PowerPoint template placeholders
    Description:
        Analyze a PowerPoint template and return a list of detected placeholder names
        that can be populated when generating a new presentation.
    Args:
        template_path: Full file path of the PowerPoint template (.pptx)
    Returns:
        List of placeholder names detected in the template
    """
    return preview_ppt_placeholders(template_path)

async def tool_validate_ppt_generation_request(template_path: str = Field(description="Full file path of the PowerPoint template (.pptx)"),
    output_path: str = Field(description="Full file path for the generated PowerPoint (.pptx)"),
    placeholders: dict = Field(
        description=(
            "Dictionary of placeholder values that will be used to fill the template. "
            "The structure should match the placeholders present in the template."
        )
    ),) -> bool:
    """
    Name:
        Validate PowerPoint generation request
    Description:
        Validate whether a PowerPoint generation request is feasible. This may include checking that
        the template file exists, required placeholders are provided, and the output path is valid.
    Args:
        template_path: Full file path of the PowerPoint template (.pptx)
        output_path: Full file path for the generated PowerPoint (.pptx)
        placeholders: Dictionary of placeholder values that will be used to fill the template
    Returns:
        True if the request is considered valid, False otherwise
    """
    return validate_ppt_generation_request(template_path, output_path, placeholders)
