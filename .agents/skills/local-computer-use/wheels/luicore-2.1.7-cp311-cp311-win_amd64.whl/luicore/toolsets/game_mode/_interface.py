# coding: utf-8
from .tools import is_game_mode_enabled, set_game_mode, open_game_mode_settings


async def tool_open_game_mode_settings() -> bool:
    """
    Opens the Windows Game Mode settings panel.
    User can manually enable or disable Game Mode from there.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return open_game_mode_settings()


async def tool_is_game_mode_enabled() -> bool:
    """
    Check if Windows Game Mode is currently enabled.

    Args:
        None

    Returns:
        bool: True if Game Mode is enabled, False otherwise.
    """
    return is_game_mode_enabled()

async def tool_set_game_mode(enable: bool) -> bool:
    """
    Enable or disable Windows Game Mode.

    Args:
        enable (bool): True to enable Game Mode, False to disable.
    Returns:
        bool: True if the operation was successful, False otherwise.
    """
    return set_game_mode(enable)
