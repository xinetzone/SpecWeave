# coding: utf-8
from .tools import hibernate_computer, shutdown_computer, restart_computer, cancel_shutdown_restart, sleep_computer


async def tool_shutdown_computer(delay_seconds: int = 30) -> bool:
    '''
    Name: Shutdown Computer
    Description: Shuts down the computer after a specified delay.
    Args:
        delay_seconds (int): The delay in seconds before shutting down the computer, default is 30 seconds.
    Returns:
        bool: True if the shutdown command was successful, False otherwise.
    '''
    return shutdown_computer(delay_seconds)

async def tool_restart_computer(delay_seconds: int = 30) -> bool:
    '''
    Name: Restart Computer
    Description: Restarts the computer after a specified delay.
    Args:
        delay_seconds (int): The delay in seconds before restarting the computer, default is 30 seconds.
    Returns:
        bool: True if the restart command was successful, False otherwise.
    '''
    return restart_computer(delay_seconds)

async def tool_cancel_shutdown_restart() -> bool:
    '''
    Name: Cancel Shutdown/Restart
    Description: Cancels a pending shutdown or restart.
    Returns:
        bool: True if the cancel command was successful, False otherwise.
    '''
    return cancel_shutdown_restart()

async def tool_hibernate_computer() -> dict:
    '''
    Name: Hibernate/休眠 Computer
    Description: Puts the computer into hibernation mode/将电脑置于休眠模式。
    Returns:
        dict: A dictionary containing the result of the hibernate command.
    '''

    ret = hibernate_computer()

    # for customer tx
    title = "已为您设置休眠，电脑即将进入休眠状态" if ret else "休眠失败，请检查系统设置或权限"

    ret_tx = {
        "title": title,
        "message": {
                "type": "plain_text",
                "data": ""
            },
        "association": {
            "title1": "休眠", 
            "title2": "电源管理"
            },
        "controls": [],
        "finished": True,
        "result": ret,
    }

    return ret_tx

async def tool_sleep_computer() -> dict:
    '''
    Name: Sleep/睡眠 Computer
    Description: Puts the computer into sleep mode/将电脑置于睡眠模式。
    Returns:
        dict: A dictionary containing the result of the sleep command.
    '''

    ret = sleep_computer()

    # for customer tx
    title = "已为您设置睡眠，电脑即将进入睡眠状态" if ret else "睡眠失败，请检查系统设置或权限"

    ret_tx = {
        "title": title,
        "message": {
                "type": "plain_text",
                "data": ""
            },
        "association": {
            "title1": "睡眠", 
            "title2": "电源管理"
            },
        "controls": [],
        "finished": True,
        "result": ret,
    }

    return ret_tx