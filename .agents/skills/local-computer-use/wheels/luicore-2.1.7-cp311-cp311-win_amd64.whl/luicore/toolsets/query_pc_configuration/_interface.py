# coding: utf-8
from .tools import get_full_pc_configuration
from .tools import open_pc_configuration_panel
from .tools import get_pc_warranty_information


async def tool_get_full_pc_configuration() -> list:
    """
    Query and Get a full overview of the current PC configuration.

    This includes key hardware details such as CPU, GPU and memory information.

    Args:
        None

    Returns:
        list: A structured payload representing the full PC configuration.
    """
    return get_full_pc_configuration()

async def tool_open_pc_configuration_panel() -> None:
    """
    Opens the Windows PC configuration panel.

    This opens the "Settings > About" page in Windows to display detailed system information.

    Args:
        None

    Returns:
        None
    """
    open_pc_configuration_panel()


async def tool_get_pc_warranty_information() -> list:
    """
    Gets the PC warranty information.

    This typically includes warranty status and related warranty details.

    Args:
        None

    Returns:
        list: A structured payload containing the PC warranty information.
    """
    return get_pc_warranty_information()
