# coding: utf-8
from pydantic import Field
from .tools import list_wechat_accounts, list_chat_sessions, get_chat_session_detail, export_chat_records, preview_chat_records, get_export_status


async def tool_list_wechat_accounts() -> list[str]:
    """
    Name:
        List WeChat accounts
    Description:
        List all available WeChat accounts (e.g., multiple logged-in users or data directories).
    Returns:
        A list of WeChat account identifiers.
    """
    return list_wechat_accounts()

async def tool_list_chat_sessions(account_id: str = Field(description="WeChat account identifier")) -> list[dict]:
    """
    Name:
        List chat sessions
    Description:
        List chat sessions for the specified WeChat account, including basic metadata.
    Args:
        account_id: WeChat account identifier whose chat sessions will be listed.
    Returns:
        A list of chat session metadata objects, each containing fields such as:
        - session_id: unique session/conversation identifier
        - name: chat name or remark
        - type: chat type (e.g., 'single', 'group', 'official')
    """
    return list_chat_sessions(account_id)

async def tool_get_chat_session_detail(account_id: str = Field(description="WeChat account identifier"),
    session_id: str = Field(description="Chat session identifier"),) -> dict:
    """
    Name:
        Get chat session detail
    Description:
        Get detailed metadata for a specific chat session of the given WeChat account.
    Args:
        account_id: WeChat account identifier.
        session_id: Chat session identifier.
    Returns:
        Chat session detail object, such as:
        - session_id
        - name
        - type
        - member_count
        - members (optional)
    """
    return get_chat_session_detail(account_id, session_id)

async def tool_export_chat_records(account_id: str = Field(description="WeChat account identifier", default = None),
    output_path: str = Field(description="Target file path for exported chat records", default = None),
    format: str = Field(
        default="html",
        description="Export format, e.g., 'html', 'txt', 'markdown', 'json'",
    ),
    start_time: str | None = Field(
        default=None,
        description="Start time filter in ISO 8601 format (e.g., '2023-01-01T00:00:00'), inclusive. If omitted, exports from the earliest record.",
    ),
    end_time: str | None = Field(
        default=None,
        description="End time filter in ISO 8601 format (e.g., '2023-12-31T23:59:59'), inclusive. If omitted, exports up to the latest record.",
    ),
    include_media: bool = Field(
        default=True,
        description="Whether to include media message references (images, videos, files, voice) in the export.",
    ),) -> bool:
    """
    Name:
        Export chat records
    Description:
        Export chat records for the specified WeChat account and chat session to a local file.
    Args:
        account_id: WeChat account identifier.
        output_path: Target file path for exported chat records.
        format: Export format, such as 'html', 'txt', 'markdown', or 'json'.
        start_time: Optional ISO 8601 start time filter (inclusive).
        end_time: Optional ISO 8601 end time filter (inclusive).
        include_media: bool value indicating whether to include media content in the export.
    Returns:
        True if the export operation is initiated successfully, False otherwise.
    """
    return export_chat_records(account_id, output_path, format, start_time, end_time, include_media)

async def tool_preview_chat_records(account_id: str = Field(description="WeChat account identifier"),
    session_id: str = Field(description="Chat session identifier"),
    limit: int = Field(
        default=50,
        description="Maximum number of messages to preview.",
        ge=1,
        le=500,
    ),
    offset: int = Field(
        default=0,
        description="Offset from the latest message; 0 means start from the most recent.",
        ge=0,
    ),
    order: str = Field(
        default="desc",
        description="Message order: 'asc' (from oldest to newest) or 'desc' (from newest to oldest).",
    ),) -> list[dict]:
    """
    Name:
        Preview chat records
    Description:
        Preview a subset of chat records for a specific chat session.
    Args:
        account_id: WeChat account identifier.
        session_id: Chat session identifier.
        limit: Maximum number of messages to return (1-500).
        offset: Offset from the latest message (0-based).
        order: Sort order, 'asc' for time ascending, 'desc' for time descending.
    Returns:
        A list of message objects, each potentially containing:
        - message_id
        - sender
        - content
        - msg_type
        - timestamp
    """
    return preview_chat_records(account_id, session_id, limit, offset, order)

async def tool_get_export_status(account_id: str = Field(description="WeChat account identifier"),
    session_id: str = Field(description="Chat session identifier"),
    output_path: str = Field(description="Target file path used when starting export"),) -> dict:
    """
    Name:
        Get export status
    Description:
        Query the status of a previously initiated chat records export task.
    Args:
        account_id: WeChat account identifier.
        session_id: Chat session identifier.
        output_path: Target file path used when the export was requested.
    Returns:
        Status object, such as:
        - status: 'pending', 'running', 'completed', 'failed'
        - progress: percentage (0-100)
        - error: error message if status is 'failed'
    """
    return get_export_status(account_id, session_id, output_path)
