# coding: utf-8
from .tools import open_system_sound_settings, set_master_volume, get_master_volume
from .tools import increase_volume_by_value, decrease_volume_by_value
from typing import Union


async def tool_open_system_sound_settings() -> bool:
    """
    Opens the system sound settings panel to adjust volume.

    Args:
        None

    Returns:
        bool: True if the panel was opened successfully, False otherwise.
    """
    return open_system_sound_settings()

async def tool_set_master_volume(level: int = 50) -> bool:
    """
    Sets the system master output volume.

    Args:
        level (int): The master volume level, from 0 to 100, default is 50.

    Returns:
        bool: True if successful, False otherwise.
    """
    return set_master_volume(level)

async def tool_get_master_volume() -> int:
    """
    Gets the current system master output volume.

    Args:
        None

    Returns:
        int: The current master volume level, from 0 to 100.
    """
    return get_master_volume()

async def tool_increase_volume_by_value(increment: int = 5) -> int:
    """
    Increases the system master output volume by a fixed value.

    Args:
        increment (int): The value to increase the volume by. Default is 5.

    Returns:
        int: The new master volume level after the increase.
    """
    return increase_volume_by_value(increment)

async def tool_decrease_volume_by_value(decrement: int = 5) -> int:
    """
    Decreases the system master output volume by a fixed value.

    Args:
        decrement (int): The value to decrease the volume by. Default is 5.

    Returns:
        int: The new master volume level after the decrease.
    """
    return decrease_volume_by_value(decrement)
