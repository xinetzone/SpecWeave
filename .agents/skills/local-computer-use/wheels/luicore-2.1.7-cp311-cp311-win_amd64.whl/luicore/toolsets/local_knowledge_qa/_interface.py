# coding: utf-8
from pydantic import Field
from .tools import query_knowledge_base, list_knowledge_collections, query_collection, summarize_entries


async def tool_query_knowledge_base(query: str = Field(description="User's natural language question"),
    top_k: int = Field(default=5, ge=1, le=50, description="Maximum number of results to retrieve"),) -> list[dict]:
    """
    Name:
        Query local knowledge base
    Description:
        Query the local knowledge base using a natural language question and return a list of relevant entries.
        The result list is ordered from most to least relevant.
    Args:
        query: User's natural language question.
        top_k: Maximum number of results to retrieve (1-50).
    Returns:
        A list of knowledge entries, each represented as a dictionary. Typical fields may include:
            - id: unique identifier of the entry
            - score: relevance score
            - title: title or short description
            - content: main content text
            - metadata: optional metadata dictionary
    """
    return query_knowledge_base(query, top_k)

async def tool_list_knowledge_collections() -> list[dict]:
    """
    Name:
        List knowledge collections
    Description:
        List all available knowledge collections in the local knowledge base.
    Returns:
        A list of collection descriptors, each represented as a dictionary. Typical fields may include:
            - id: unique identifier of the collection
            - name: human-readable collection name
            - description: optional description of the collection
            - size: number of entries in the collection (if available)
    """
    return list_knowledge_collections()

async def tool_query_collection(collection_id: str = Field(description="Target collection identifier"),
    query: str = Field(description="User's natural language question scoped to the collection"),
    top_k: int = Field(default=5, ge=1, le=50, description="Maximum number of results to retrieve"),) -> list[dict]:
    """
    Name:
        Query specific knowledge collection
    Description:
        Query a specific knowledge collection using a natural language question and return a list of relevant entries.
    Args:
        collection_id: Target collection identifier.
        query: User's natural language question scoped to the collection.
        top_k: Maximum number of results to retrieve (1-50).
    Returns:
        A list of knowledge entries in the specified collection, each represented as a dictionary.
        Typical fields may include:
            - id: unique identifier of the entry
            - score: relevance score
            - title: title or short description
            - content: main content text
            - metadata: optional metadata dictionary
    """
    return query_collection(collection_id, query, top_k)

async def tool_summarize_entries(entry_ids: list[str] = Field(description="List of knowledge entry ids to summarize"),
    max_tokens: int = Field(default=512, ge=32, le=4096, description="Maximum length of the generated summary"),) -> str:
    """
    Name:
        Summarize knowledge entries
    Description:
        Generate a concise summary based on one or more knowledge entries.
    Args:
        entry_ids: List of knowledge entry ids to summarize.
        max_tokens: Maximum length of the generated summary.
    Returns:
        A summarized text that aggregates the key information contained in the specified entries.
    """
    return summarize_entries(entry_ids, max_tokens)
