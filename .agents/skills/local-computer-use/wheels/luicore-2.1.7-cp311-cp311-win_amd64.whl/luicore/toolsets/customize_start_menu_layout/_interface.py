# coding: utf-8
from pydantic import Field
from .tools import set_start_menu_layout


async def tool_set_start_menu_layout(layout: int = 0) -> None:
    """
    Sets the Windows Start menu layout.

    Args:
        layout (int): The layout mode. Valid values:
            0 - Default layout
            1 - More pinned items
            2 - More recommendations

    Returns:
        None
    """
    return set_start_menu_layout(layout)
