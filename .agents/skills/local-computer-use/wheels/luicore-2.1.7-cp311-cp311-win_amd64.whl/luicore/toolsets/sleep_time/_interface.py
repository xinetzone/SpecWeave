# coding: utf-8
from .tools import set_system_sleep_time, get_system_sleep_time, set_system_hibernate_time


async def tool_set_system_sleep_time(ac_time: int = -1, dc_time: int = -1) -> str:
    """
    Sets the system sleep time in minutes.

    Args:
        ac_time (int): Sleep timeout in minutes when powered by AC. -1 means unspecified, 0 means never sleep.
        dc_time (int): Sleep timeout in minutes when powered by battery. -1 means unspecified, 0 means never sleep.

    Returns:
        str: A description string of the current power state and sleep time settings.
    """
    return set_system_sleep_time(ac_time, dc_time)

async def tool_get_system_sleep_time() -> str:
    """
    Gets the current system sleep time settings.

    Args:
        None

    Returns:
        str: A description string of the current power state and sleep time settings.
    """
    battery, ac_time, dc_time = get_system_sleep_time()
    if battery is not None and not battery.power_plugged:
        power_state = "当前正使用电池"
        sleep_time = f"，睡眠时间为 {dc_time} 分钟" if dc_time > 0 else "，永不睡眠"
    else:
        power_state = "当前已接通电源"
        sleep_time = f"，睡眠时间为 {ac_time} 分钟" if ac_time > 0 else "，永不睡眠"

    return power_state + sleep_time

async def tool_set_never_sleep() -> str:
    """
    Sets the system to never sleep/睡眠.

    Args:
        None

    Returns:
        str: A description string of the current power state and sleep time settings.
    """
    return set_system_sleep_time(0, 0)

async def tool_set_never_hibernate() -> str:
    """
    Sets the system to never hibernate/休眠.

    Args:
        None

    Returns:
        str: A description string of the current power state and hibernate time settings.
    """
    return set_system_hibernate_time(0, 0)