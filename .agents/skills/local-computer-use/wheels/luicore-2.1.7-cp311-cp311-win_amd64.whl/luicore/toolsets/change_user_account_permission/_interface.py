# coding: utf-8
from .tools import set_user_permission_level


# async def tool_get_user_permissions() -> str:
#     """
#     Gets the current user permissions.
#
#     Args:
#         None
#
#     Returns:
#         str: The current permission information for the user.
#     """
#     return get_user_permissions()

async def tool_set_user_permission_level() -> bool:
    """
    Sets the permission level for the current user account.

    Args:
        None

    Returns:
        bool: True if the permission level was set successfully, False otherwise.
    """
    return set_user_permission_level()