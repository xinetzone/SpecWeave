# coding: utf-8
from .tools import get_ip_info, open_network_settings_panel


async def tool_get_ip_address() -> list:
    """
    Gets the IP address of active network interfaces.

    Args:
        None

    Returns:
        list: A structured payload containing IP information of active network interfaces.
    """
    return get_ip_info()

async def open_advanced_network_settings_panel():
    """
    Opens the advanced network settings panel of the operating system.

    Args:
        None

    Returns:
        bool: True if the advanced network settings panel was successfully opened, False otherwise.
    """
    return open_network_settings_panel()
