# coding: utf-8
from .tools import open_services_manager_panel


async def tool_open_service_manager_panel() -> bool:
    """
    Opens the service manager panel.

    Args:
        None

    Returns:
        bool: True if the panel was opened successfully, False otherwise.
    """
    return open_services_manager_panel()
