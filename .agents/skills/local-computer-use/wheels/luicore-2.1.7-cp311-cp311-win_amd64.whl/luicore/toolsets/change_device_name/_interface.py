# coding: utf-8
from .tools import change_device_name, get_device_name


async def tool_change_device_name(new_name: str = "") -> bool:
    """
    Changes the device display name.

    Args:
        new_name (str): The new display name for the device. The name must only contain ENGLISH letters, numbers, and hyphens (-). If omitted, opens the system rename entry point.

    Returns:
        bool: True if the device name was successfully changed, False otherwise.
    """
    return change_device_name(new_name)

async def tool_get_device_name() -> str:
    """
    Retrieves the current display name of the device.

    Args:
        None

    Returns:
        str: The current display name of the device.
    """
    return get_device_name()
