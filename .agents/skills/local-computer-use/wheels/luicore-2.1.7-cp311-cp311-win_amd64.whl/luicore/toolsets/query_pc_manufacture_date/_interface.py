# coding: utf-8
from .tools import get_pc_manufacture_date


async def tool_get_pc_manufacture_date() -> str:
    """
    Gets manufacture date of the current PC.
    Also includes BIOS version information.

    Args:
        None.

    Returns:
        str: A string description of the manufacture date and BIOS version,
        for example "Manufacture Date: 2023-01-01, BIOS Version: ABC123".
    """
    return get_pc_manufacture_date()
