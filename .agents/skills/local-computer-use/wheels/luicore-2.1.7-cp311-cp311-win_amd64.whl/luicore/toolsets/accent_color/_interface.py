# coding: utf-8
from .tools import open_accent_color_setting


async def tool_open_accent_color_setting() -> bool:
    """
    Opens the Windows accent color i.e. theme color settings page.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return open_accent_color_setting()
