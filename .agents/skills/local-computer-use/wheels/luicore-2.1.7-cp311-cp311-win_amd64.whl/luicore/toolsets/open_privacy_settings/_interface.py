# coding: utf-8
from .tools import open_privacy_settings


async def tool_open_privacy_settings() -> bool:
    """
    Opens the privacy settings.

    Args:
        None.

    Returns:
        bool: True if successful, False otherwise.
    """
    return open_privacy_settings()