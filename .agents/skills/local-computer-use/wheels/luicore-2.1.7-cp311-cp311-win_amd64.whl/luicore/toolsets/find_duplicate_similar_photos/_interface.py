# coding: utf-8
from pydantic import Field
from .tools import scan_duplicate_photos, list_photo_groups, delete_photo_group, get_photo_group_summary


from typing import List

async def tool_scan_duplicate_photos(directory: str = Field(description="Root directory to scan for duplicate photos"),
    recursive: bool = Field(default=True, description="Whether to recursively scan subdirectories"),
    hash_algorithm: str = Field(
        default="perceptual",
        description="Hash algorithm to use for comparison, e.g. 'md5', 'sha1', 'average', 'phash', 'dhash'"
    ),
    similarity_threshold: int = Field(
        default=100,
        ge=0,
        le=100,
        description="Similarity threshold (0-100). 100 means only identical files are grouped."
    ),) -> List[List[str]]:
    """
    Name:
        Scan duplicate or similar photos
    Description:
        Scan the given directory for duplicate or visually similar photos and group
        the matching files together. Each inner list represents one group of
        duplicate/similar photos.
    Args:
        directory: Root directory to scan for duplicate photos
        recursive: Whether to recursively scan subdirectories
        hash_algorithm: Hash algorithm to use for comparison, e.g. 'md5', 'sha1', 'average', 'phash', 'dhash'
        similarity_threshold: Similarity threshold (0-100). 100 means only identical files are grouped.
    Returns:
        A list of groups of duplicate/similar photos. Each group is a list of file paths.
    """
    return scan_duplicate_photos(directory, recursive, hash_algorithm, similarity_threshold)

async def tool_list_photo_groups(directory: str = Field(description="Directory where previous scan results are stored"),) -> List[List[str]]:
    """
    Name:
        List last detected photo groups
    Description:
        List groups of duplicate or similar photos previously detected for the given directory.
        This is typically used after a scan operation has completed and stored its results.
    Args:
        directory: Directory where previous scan results are stored
    Returns:
        A list of groups of duplicate/similar photos. Each group is a list of file paths.
    """
    return list_photo_groups(directory)

async def tool_delete_photo_group(files: List[str] = Field(description="List of photo file paths to delete"),
    dry_run: bool = Field(
        default=True,
        description="If True, only simulate deletion and return what would be deleted."
    ),) -> bool:
    """
    Name:
        Delete a group of photos
    Description:
        Delete a group of duplicate or similar photos. Optionally perform a dry run
        to preview which files would be deleted.
    Args:
        files: List of photo file paths to delete
        dry_run: If True, only simulate deletion and return what would be deleted
    Returns:
        True on success, False on failure.
    """
    return delete_photo_group(files, dry_run)

async def tool_get_photo_group_summary(directory: str = Field(description="Directory that was scanned"),) -> dict:
    """
    Name:
        Get photo duplicate summary
    Description:
        Get a summary of duplicate/similar photo detection within the given directory,
        such as number of groups, total files scanned and potential space savings.
    Args:
        directory: Directory that was scanned
    Returns:
        A dictionary with summary statistics (e.g. group_count, duplicate_file_count, total_size_bytes)
    """
    return get_photo_group_summary(directory)
