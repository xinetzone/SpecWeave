# coding: utf-8
from .tools import set_login_password


async def tool_set_login_password() -> bool:
    """
    Sets the login password.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return set_login_password()
