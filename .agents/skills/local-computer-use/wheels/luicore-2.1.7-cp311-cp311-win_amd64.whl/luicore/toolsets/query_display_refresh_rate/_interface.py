# coding: utf-8
from .tools import get_display_refresh_rate


async def tool_get_display_refresh_rate() -> str:
    """
    Queries the current display refresh rate.

    Args:
        None

    Returns:
        str: The current display refresh rate, such as "60Hz" or "144Hz".
    """
    return get_display_refresh_rate()
