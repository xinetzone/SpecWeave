# coding: utf-8
from .tools import open_monitor_settings, set_monitor_brightness, get_monitor_brightness
from .tools import increase_monitor_brightness_by_value, decrease_monitor_brightness_by_value


async def tool_open_monitor_settings() -> bool:
    """
    Opens the monitor settings panel.

    Args:
        None

    Returns:
        bool: True if the panel was opened successfully, False otherwise.
    """
    open_monitor_settings()
    return True

async def tool_set_monitor_brightness(level: int) -> bool:
    """
    Sets the monitor brightness.

    Args:
        level (int): The brightness level, from 0 to 100.

    Returns:
        bool: True if successful, False otherwise.
    """
    return set_monitor_brightness(level)

async def tool_get_monitor_brightness() -> int:
    """
    Gets the current monitor brightness level.

    Args:
        None

    Returns:
        int: The current monitor brightness level, from 0 to 100.
    """
    return get_monitor_brightness()


async def tool_increase_monitor_brightness(increment: int = 5) -> int:
    """
    Increases the monitor brightness by a fixed value.

    Args:
        increment (int): The value to increase the brightness by. Default is 5.

    Returns:
        int: The new monitor brightness level after the increase.
    """
    return increase_monitor_brightness_by_value(increment)

async def tool_decrease_monitor_brightness(decrement: int = 5) -> int:
    """
    Decreases the monitor brightness by a fixed value.

    Args:
        decrement (int): The value to decrease the brightness by. Default is 5.

    Returns:
        int: The new monitor brightness level after the decrease.
    """
    return decrease_monitor_brightness_by_value(decrement)


if __name__ == "__main__":
    # Example usage:
    print(f"当前亮度: {get_monitor_brightness()}")
    print("增加亮度5%")
    increase_monitor_brightness_by_value(5)
    print(f"当前亮度: {get_monitor_brightness()}")
    print("减少亮度10%")
    decrease_monitor_brightness_by_value(10)
    print(f"当前亮度: {get_monitor_brightness()}")

    open_monitor_settings()