# coding: utf-8
from .tools import set_hide_file_extensions


async def tool_set_hide_file_extensions(show: bool = False) -> bool:
    """
    Sets whether to show file extensions in Windows Explorer.

    Args:
        show (bool): Whether to show file extensions. True to show, False to hide.

    Returns:
        bool: True if successful, False otherwise.
    """
    return set_hide_file_extensions(show)
