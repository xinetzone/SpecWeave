# coding: utf-8
from .tools import set_auto_snap_layout_config


async def tool_set_auto_snap_layout_config() -> str:
    """
    Configures automatic window snap layout.

    Args:
        None

    Returns:
        str: A textual description of the configuration result.
    """
    return set_auto_snap_layout_config()
