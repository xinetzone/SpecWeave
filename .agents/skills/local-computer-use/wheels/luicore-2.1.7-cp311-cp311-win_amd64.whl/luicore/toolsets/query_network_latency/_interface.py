# coding: utf-8
from .tools import query_network_latency


async def tool_query_network_latency() -> list:
    """
    Queries overall network latency.

    Args:
        None.

    Returns:
        list: A structured payload describing network latency, including minimum, maximum
        and average latency, as well as packet loss and related information.
    """
    return query_network_latency()

async def tool_diagnose_network_latency(host: str, count: int = 4, timeout_ms: int = 5000) -> list:
    """
    Diagnoses network latency for a specific host.

    Args:
        host (str): Target host name or IP address to diagnose.
        count (int): Number of echo requests (pings) to send, default is 4.
        timeout_ms (int): Timeout in milliseconds for each request, default is 5000 ms.

    Returns:
        list: A structured diagnostic summary describing network latency and connectivity
        status to the specified host, including statistics such as minimum, maximum and
        average latency and packet loss if available.
    """
    return query_network_latency(host, count, timeout_ms)
