# coding: utf-8
from pydantic import Field
from .tools import pick_color_at_screen_position, pick_color_under_cursor, pick_color_region_average, pick_color_with_format


async def tool_pick_color_at_screen_position(x: int = 0, y: int = 0) -> str:
    """
    Name:
        Pick color at screen position
    Description:
        Pick the color at the given screen coordinates (x, y) across all applications.
        Returns the color in hexadecimal RGB format, e.g. "#RRGGBB".
    Args:
        x: Screen x coordinate in pixels.
        y: Screen y coordinate in pixels.
    Returns:
        Color value in hexadecimal RGB format, e.g. "#RRGGBB".
    """
    return pick_color_at_screen_position(x, y)

async def tool_pick_color_under_cursor() -> str:
    """
    Name:
        Pick color under cursor
    Description:
        Pick the color under the current mouse cursor position across all applications.
        Returns the color in hexadecimal RGB format, e.g. "#RRGGBB".
    Returns:
        Color value in hexadecimal RGB format, e.g. "#RRGGBB".
    """
    return pick_color_under_cursor()

async def tool_pick_color_region_average(left: int = Field(description="Left coordinate of the region in pixels"),
    top: int = Field(description="Top coordinate of the region in pixels"),
    right: int = Field(description="Right coordinate of the region in pixels"),
    bottom: int = Field(description="Bottom coordinate of the region in pixels")) -> str:
    """
    Name:
        Pick average color in region
    Description:
        Capture the screen region defined by (left, top, right, bottom) and compute
        the average color of all pixels in that region. Returns the color in
        hexadecimal RGB format, e.g. "#RRGGBB".
    Args:
        left: Left coordinate of the region in pixels.
        top: Top coordinate of the region in pixels.
        right: Right coordinate of the region in pixels.
        bottom: Bottom coordinate of the region in pixels.
    Returns:
        Average color value in hexadecimal RGB format, e.g. "#RRGGBB".
    """
    return pick_color_region_average(left, top, right, bottom)

async def tool_pick_color_with_format(x: int = Field(description="Screen x coordinate (pixels)"),
    y: int = Field(description="Screen y coordinate (pixels)"),
    fmt: str = Field(description="Color format: 'hex', 'rgb', or 'rgba'")) -> str:
    """
    Name:
        Pick color at position with format
    Description:
        Pick the color at the given screen coordinates (x, y) and return it in the
        specified format.
    Args:
        x: Screen x coordinate in pixels.
        y: Screen y coordinate in pixels.
        fmt: Desired color format: 'hex', 'rgb', or 'rgba'.
    Returns:
        Color value in the requested format, e.g. "#RRGGBB", "R,G,B", or "R,G,B,A".
    """
    return pick_color_with_format(x, y, fmt)
