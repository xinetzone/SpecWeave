# coding: utf-8
from .tools import open_time_language_home


async def tool_open_time_language_home() -> bool:
    """
    Opens the Windows time and language settings.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return open_time_language_home()
