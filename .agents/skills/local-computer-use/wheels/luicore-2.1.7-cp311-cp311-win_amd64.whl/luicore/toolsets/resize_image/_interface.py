# coding: utf-8
from pydantic import Field
from .tools import resize_image, get_image_info

from typing import Optional, Literal

async def tool_resize_image(input_path: str = Field(description="Path of the source image to be resized"),
    output_path: str = Field(description="Path to save the resized image"),
    width: int = Field(description="Target width in pixels (must be > 0)"),
    height: int = Field(description="Target height in pixels (must be > 0)"),
    keep_aspect: bool = Field(
        default=True,
        description=(
            "Whether to preserve the original aspect ratio. "
            "If True, the image fits within width×height with no distortion."
        ),
    ),
    fit_mode: Literal["fit", "fill", "stretch"] = Field(
        default="fit",
        description=(
            "Resizing strategy when keep_aspect is True:\n"
            "- 'fit': fit inside the target box, may leave blank margins.\n"
            "- 'fill': fill the entire target box and crop overflow.\n"
            "When keep_aspect is False, this value is ignored and image is stretched."
        ),
    ),
    quality: Optional[int] = Field(
        default=None,
        description=(
            "Optional output quality (1-100) for lossy formats (e.g. JPEG). "
            "If None, use a reasonable default for the format."
        ),
    ),
    overwrite: bool = Field(
        default=False,
        description="Whether to overwrite output_path if the file already exists.",
    ),) -> str:
    """
    Name:
        Resize image
    Description:
        Resize an input image to the specified width and height, with optional aspect ratio
        preservation and quality settings. Returns the actual output file path.
    Args:
        input_path: Path of the source image to be resized.
        output_path: Path to save the resized image.
        width: Target width in pixels (must be > 0).
        height: Target height in pixels (must be > 0).
        keep_aspect: Whether to preserve the original aspect ratio.
        fit_mode: Resizing strategy when keep_aspect is True ('fit', 'fill', 'stretch').
        quality: Optional output quality (1-100) for lossy formats.
        overwrite: Whether to overwrite output_path if already exists.
    Returns:
        The path of the resized image file.
    """
    return resize_image(input_path, output_path, width, height, keep_aspect, fit_mode, quality, overwrite)

async def tool_get_image_info(input_path: str = Field(description="Path of the image to inspect"),) -> dict:
    """
    Name:
        Get image info
    Description:
        Get basic information of an image file, such as width, height and format.
    Args:
        input_path: Path of the image to inspect.
    Returns:
        A JSON-serializable dict containing:
        - width: image width in pixels
        - height: image height in pixels
        - format: image format string (e.g. 'JPEG', 'PNG')
        - mode: color mode (e.g. 'RGB', 'RGBA', 'L')
    """
    return get_image_info(input_path)
