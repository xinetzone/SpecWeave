# coding: utf-8
from .tools import get_memory_usage


async def tool_get_memory_info() -> list:
    """
    Gets system memory information.

    Returns:
        list: A structured payload describing system memory information.
    """
    return get_memory_usage()
