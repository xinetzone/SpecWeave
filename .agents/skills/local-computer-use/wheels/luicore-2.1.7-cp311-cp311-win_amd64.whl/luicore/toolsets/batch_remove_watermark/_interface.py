# coding: utf-8
from pydantic import Field
from .tools import batch_remove_watermark_from_images, preview_watermark_removal, list_supported_image_formats, get_last_batch_result


async def tool_batch_remove_watermark_from_images(input_directory: str = Field(description="Directory path containing images to process"),
    output_directory: str = Field(description="Directory path to save processed images"),
    watermark_description: str = Field(
        description="Text description of the watermark position/shape, e.g. 'bottom-right logo', 'center text', 'top banner'"
    ),
    overwrite: bool = Field(
        default=False,
        description="Whether to overwrite existing files in output_directory when filenames collide"
    ),) -> bool:
    """
    Name:
        Batch remove watermark from images
    Description:
        Batch-process all images in input_directory to remove the specified watermark and save results to output_directory.
        Returns True on success, False on failure.
    Args:
        input_directory: Directory path containing images to process.
        output_directory: Directory path to save processed images.
        watermark_description: Human-readable description of watermark type and location.
        overwrite: Whether to overwrite existing files in output_directory when filenames collide.
    Returns:
        True on success, False on failure.
    """
    return batch_remove_watermark_from_images(input_directory, output_directory, watermark_description, overwrite)

async def tool_preview_watermark_removal(image_path: str = Field(description="Full path to a single image file to preview watermark removal"),
    watermark_description: str = Field(
        description="Text description of the watermark position/shape, e.g. 'bottom-right logo', 'center text', 'top banner'"
    ),) -> str:
    """
    Name:
        Preview watermark removal for a single image
    Description:
        Run watermark removal on a single image and return the path to the preview image without watermark.
    Args:
        image_path: Full path to the image file.
        watermark_description: Human-readable description of watermark type and location.
    Returns:
        Path to the generated preview image.
    """
    return preview_watermark_removal(image_path, watermark_description)

async def tool_list_supported_image_formats() -> list[str]:
    """
    Name:
        List supported image formats
    Description:
        Get the list of image file extensions that can be processed by the batch watermark removal tool.
    Returns:
        List of supported image file extensions, e.g. ['.jpg', '.png', '.bmp'].
    """
    return list_supported_image_formats()

async def tool_get_last_batch_result() -> dict:
    """
    Name:
        Get last batch result
    Description:
        Get summary information about the most recent batch watermark removal operation.
    Returns:
        A dictionary with statistics such as:
        - total_files
        - processed_files
        - failed_files
        - output_directory
        - error_messages (if any)
    """
    return get_last_batch_result()
