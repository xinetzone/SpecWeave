# coding: utf-8
from .tools import increase_mouse_sensitivity_by_value, increase_mouse_sensitivity_by_percentage
from .tools import decrease_mouse_sensitivity_by_value, decrease_mouse_sensitivity_by_percentage
from .tools import set_mouse_sensitivity, get_mouse_sensitivity
from .tools import open_mouse_sensitivity_settings


async def tool_get_mouse_sensitivity() -> int:
    """
    Gets the current mouse sensitivity level.

    Args:
        None

    Returns:
        int: The current mouse sensitivity level.
    """
    return get_mouse_sensitivity()

async def tool_set_mouse_sensitivity(sensitivity_level: int = 10) -> bool:
    """
    Sets the mouse sensitivity to an absolute level between 1 and 20.

    Args:
        sensitivity_level (int): The absolute mouse sensitivity level (1–20), -1 means unspecified, default is 10.

    Returns:
        bool: True if the operation was successful, False otherwise.
    """
    return set_mouse_sensitivity(sensitivity_level)

async def tool_open_mouse_sensitivity_settings() -> str:
    """
    Opens the Windows mouse sensitivity settings page.

    Args:
        None

    Returns:
        str: A message indicating the result of the operation.
    """
    return open_mouse_sensitivity_settings()

async def tool_increase_mouse_sensitivity_by_value(increment: int = 0) -> str:
    """
    Increases the mouse sensitivity by a fixed value.

    Args:
        increment (int): The fixed value (1-20) to increase the mouse sensitivity, -1 means unspecified.

    Returns:
        str: A message indicating the result of the operation.
"""
    return increase_mouse_sensitivity_by_value(increment)

async def tool_increase_mouse_sensitivity_by_percentage(percentage: int = 0) -> str:
    """
    Increases the mouse sensitivity by a percentage of the maximum sensitivity.

    Args:
        percentage (int): The percentage (1-100) to increase the mouse sensitivity, -1 means unspecified.

    Returns:
        str: A message indicating the result of the operation.
    """
    return increase_mouse_sensitivity_by_percentage(percentage)

async def tool_decrease_mouse_sensitivity_by_value(decrement: int = 0) -> str:
    """
    Decreases the mouse sensitivity by a fixed value.

    Args:
        decrement (int): The fixed value (1-20) to decrease the mouse sensitivity, -1 means unspecified.

    Returns:
        str: A message indicating the result of the operation.
    """
    return decrease_mouse_sensitivity_by_value(decrement)

async def tool_decrease_mouse_sensitivity_by_percentage(percentage: int = 0) -> str:
    """
    Decreases the mouse sensitivity by a percentage of the maximum sensitivity.

    Args:
        percentage (int): The percentage (1-100) to decrease the mouse sensitivity, -1 means unspecified.

    Returns:
        str: A message indicating the result of the operation.
    """
    return decrease_mouse_sensitivity_by_percentage(percentage)