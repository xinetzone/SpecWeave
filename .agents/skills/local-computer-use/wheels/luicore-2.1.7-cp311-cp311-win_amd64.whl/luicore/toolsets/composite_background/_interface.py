# coding: utf-8
from pydantic import Field
from .tools import generate_composite_background, blur_background_region, replace_background, get_composite_background_capabilities


async def tool_generate_composite_background(foreground_path: str = Field(description="Path to the foreground image file"),
    background_path: str = Field(description="Path to the background image file"),
    output_path: str = Field(description="Path where the composite image will be saved"),
    opacity: float = Field(
        default=1.0,
        description="Opacity of the foreground image when composited over the background (0.0-1.0)"
    ),) -> str:
    """
    Name:
        Generate composite background
    Description:
        Composite a foreground image over a background image and save the result to the specified output path.
    Args:
        foreground_path: Path to the foreground image file.
        background_path: Path to the background image file.
        output_path: Path where the composite image will be saved.
        opacity: Opacity of the foreground image when composited over the background (0.0-1.0).
    Returns:
        The path of the generated composite image.
    """
    return generate_composite_background(foreground_path, background_path, output_path, opacity)

async def tool_blur_background_region(image_path: str = Field(description="Path to the image file"),
    region_x: int = Field(description="X coordinate of the top-left corner of the region to blur"),
    region_y: int = Field(description="Y coordinate of the top-left corner of the region to blur"),
    region_width: int = Field(description="Width of the region to blur"),
    region_height: int = Field(description="Height of the region to blur"),
    blur_radius: int = Field(description="Radius of the blur to apply to the region"),
    output_path: str = Field(description="Path where the processed image will be saved"),) -> str:
    """
    Name:
        Blur background region
    Description:
        Apply a blur effect to a rectangular region of the image and save the result.
    Args:
        image_path: Path to the image file.
        region_x: X coordinate of the top-left corner of the region to blur.
        region_y: Y coordinate of the top-left corner of the region to blur.
        region_width: Width of the region to blur.
        region_height: Height of the region to blur.
        blur_radius: Radius of the blur to apply to the region.
        output_path: Path where the processed image will be saved.
    Returns:
        The path of the processed image with blurred region.
    """
    return blur_background_region(image_path, region_x, region_y, region_width, region_height, blur_radius, output_path)

async def tool_replace_background(image_path: str = Field(description="Path to the original image with foreground and background"),
    new_background_path: str = Field(description="Path to the new background image"),
    output_path: str = Field(description="Path where the image with replaced background will be saved"),
    feather_radius: int = Field(
        default=10,
        description="Feather radius used when blending the foreground with the new background"
    ),) -> str:
    """
    Name:
        Replace background
    Description:
        Replace the background of an image while keeping the foreground, and save the result.
    Args:
        image_path: Path to the original image with foreground and background.
        new_background_path: Path to the new background image.
        output_path: Path where the image with replaced background will be saved.
        feather_radius: Feather radius used when blending the foreground with the new background.
    Returns:
        The path of the image with replaced background.
    """
    return replace_background(image_path, new_background_path, output_path, feather_radius)

async def tool_get_composite_background_capabilities() -> str:
    """
    Name:
        Get composite background capabilities
    Description:
        Get a description of the supported composite background operations and their parameters.
    Returns:
        A human-readable description of the composite background tool capabilities.
    """
    return get_composite_background_capabilities()
