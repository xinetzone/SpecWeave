# coding: utf-8
from .tools import open_default_apps


async def tool_open_default_apps() -> bool:
    """
    Opens the Windows Default Apps settings panel. 
    Users can then select the default applications for various file types and protocols.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return open_default_apps()
