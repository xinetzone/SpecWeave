# coding: utf-8
from .tools import set_mouse_precision, is_mouse_precision_enabled, open_mouse_precision_settings_panel


async def tool_set_mouse_precision(enable: bool) -> bool:
    """
    Sets the mouse pointer precision.

    Args:
        enable (bool): True to enable mouse pointer precision, False to disable.

    Returns:
        bool: True if the operation was successful, False otherwise.
    """
    return set_mouse_precision(enable)

async def tool_is_mouse_precision_enabled() -> bool:
    """
    Checks if mouse pointer precision is enabled.

    Args:
        None

    Returns:
        bool: True if mouse pointer precision is enabled, False otherwise.
    """
    return is_mouse_precision_enabled()

async def tool_open_mouse_precision_settings_panel() -> bool:
    """
    Opens the mouse pointer precision settings panel.

    Args:
        None

    Returns:
        bool: True if the settings panel was opened successfully, False otherwise.
    """
    return open_mouse_precision_settings_panel()
