# coding: utf-8
from .tools import switch_admin_account


async def tool_switch_admin_account() -> bool:
    """
    Switches the current session/context to the specified administrator account.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return switch_admin_account()
