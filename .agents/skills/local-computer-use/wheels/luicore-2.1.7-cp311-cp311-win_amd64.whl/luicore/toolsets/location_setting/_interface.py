# coding: utf-8
from .tools import open_location_settings


async def tool_open_location_settings() -> bool:
    """
    Opens the Windows location settings page.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return open_location_settings()
