# coding: utf-8
from .tools import open_resource_monitor


async def tool_open_resource_monitor() -> bool:
    """
    Opens the Windows Resource Monitor.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return open_resource_monitor()
