# coding: utf-8
from .tools import delete_admin_account


async def tool_delete_admin_account() -> bool:
    """
    Deletes the administrator account.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return delete_admin_account()
