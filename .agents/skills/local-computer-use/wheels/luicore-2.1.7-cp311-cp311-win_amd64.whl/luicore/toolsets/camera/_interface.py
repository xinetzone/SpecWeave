# coding: utf-8
from .tools import who_is_using_camera


async def tool_who_is_using_camera() -> list|None:
    '''
    Name: Who Is Using Camera
    Description: Gets the names of the applications currently using the camera.
    Returns:
        list|None: 
         A list of the names of the applications using the camera, or None if no camera device is available.
    '''
    return who_is_using_camera()
