# coding: utf-8
from .tools import get_battery_remaining_time_minutes


async def tool_get_battery_remaining_time_minutes() -> str:
    """
    Queries the remaining battery life.

    Args:
        None

    Returns:
        str: A description string of the remaining battery time, for example
            "Remaining battery life is approximately 120 minutes".
    """
    return get_battery_remaining_time_minutes()
