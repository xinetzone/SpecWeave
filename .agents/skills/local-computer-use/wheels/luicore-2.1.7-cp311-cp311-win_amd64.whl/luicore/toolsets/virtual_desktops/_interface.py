# coding: utf-8
from .tools import list_virtual_desktops, create_virtual_desktop, remove_all_other_virtual_desktops, switch_virtual_desktop, rename_virtual_desktop, open_virtual_desktops_settings_panel


async def tool_open_virtual_desktop_settings() -> bool:
    """
    Opens the Windows virtual desktop settings (taskbar settings panel).

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return open_virtual_desktops_settings_panel()

async def tool_list_virtual_desktops() -> list[str]:
    """
    Lists all existing virtual desktops.

    Args:
        None

    Returns:
        list[str]: A list of identifiers or names of all existing virtual desktops.
    """
    return list_virtual_desktops()

async def tool_create_virtual_desktop(name: str) -> str:
    """
    Creates a new virtual desktop with the specified name.

    Args:
        name (str): The name for the new virtual desktop.

    Returns:
        str: The identifier or name of the newly created virtual desktop.
    """
    return create_virtual_desktop(name)

async def tool_remove_virtual_desktop(desktop_id: str) -> bool:
    """
    Removes the specified virtual desktop.

    Args:
        desktop_id (str): The identifier or name of the virtual desktop to remove.

    Returns:
        bool: True if successful, False otherwise.
    """
    return remove_all_other_virtual_desktops()

async def tool_switch_virtual_desktop(desktop_id: str) -> bool:
    """
    Switches the current view to the specified virtual desktop.

    Args:
        desktop_id (str): The identifier or name of the virtual desktop to switch to.

    Returns:
        bool: True if successful, False otherwise.
    """
    return switch_virtual_desktop(desktop_id)

async def tool_rename_virtual_desktop(desktop_id: str, new_name: str) -> bool:
    """
    Renames the specified virtual desktop.

    Args:
        desktop_id (str): The identifier or current name of the virtual desktop to rename.
        new_name (str): The new name for the virtual desktop.

    Returns:
        bool: True if successful, False otherwise.
    """
    return rename_virtual_desktop(desktop_id, new_name)
