# coding: utf-8
from pydantic import BaseModel, Field
from .tools import filter_important_moment_photos, analyze_single_photo_importance, group_photos_into_moments, select_best_photo_per_moment


async def tool_filter_important_moment_photos() -> bool:
    """
    Name:
        Filter important moment photos
    """
    return filter_important_moment_photos()

async def tool_analyze_single_photo_importance() -> bool:
    """
    Name:
        Analyze single photo importance
    """
    return analyze_single_photo_importance()

async def tool_group_photos_into_moments() -> bool:
    """
    Name:
        Group photos into moments
    """
    return group_photos_into_moments()

async def tool_select_best_photo_per_moment() -> bool:
    """
    Name:
        Select best photo per moment
    """
    return select_best_photo_per_moment()
