# coding: utf-8
from .tools import set_desktop_wallpaper, open_wallpaper_settings_panel


async def tool_set_desktop_wallpaper(image_path: str = "") -> str:
    """
    Sets the desktop wallpaper.

    Args:
        image_path (str): The full file path of the wallpaper image.

    Returns:
        str: A result message indicating success or failure.
    """
    return set_desktop_wallpaper(image_path)


async def open_wallpaper_settings_panel() -> bool:
    """
    Opens the operating system wallpaper settings panel.

    Args:
        None

    Returns:
        bool: True if the settings panel was opened successfully, False otherwise.
    """
    return open_wallpaper_settings_panel()