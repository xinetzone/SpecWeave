# coding: utf-8
from pydantic import Field
from .tools import convert_file_format, detect_file_format, list_supported_formats, preview_converted_content


async def tool_convert_file_format(input_path: str = Field(description="Absolute or relative path of the source file"),
    output_path: str = Field(description="Absolute or relative path of the target file to write"),
    input_format: str = Field(
        description="Explicit input format (e.g. 'csv', 'json', 'xml', 'yaml'); "
                    "if empty, it will be inferred from input_path"
    ),
    output_format: str = Field(
        description="Output format to convert to (e.g. 'csv', 'json', 'xml', 'yaml'); "
                    "if empty, it will be inferred from output_path"
    ),
    overwrite: bool = Field(
        default=False,
        description="Whether to overwrite output_path if it already exists"
    ),) -> bool:
    """
    Name:
        Convert file format
    Description:
        Convert a file from one format to another (for example CSV <-> JSON).
        The tool reads the file from input_path, converts its structured content
        according to input_format and output_format, and writes the result
        to output_path.
    Args:
        input_path: Absolute or relative path of the source file.
        output_path: Absolute or relative path of the target file to write.
        input_format: Explicit input format (e.g. 'csv', 'json', 'xml', 'yaml');
            if empty, it will be inferred from input_path.
        output_format: Output format to convert to (e.g. 'csv', 'json', 'xml', 'yaml');
            if empty, it will be inferred from output_path.
        overwrite: Whether to overwrite output_path if it already exists.
    Returns:
        True on success, False on failure.
    """
    return convert_file_format(input_path, output_path, input_format, output_format, overwrite)

async def tool_detect_file_format(path: str = Field(description="Absolute or relative path of the file to inspect")) -> str:
    """
    Name:
        Detect file format
    Description:
        Inspect a file and return its most likely format identifier
        (for example 'csv', 'json', 'xml', 'yaml', or 'unknown').
    Args:
        path: Absolute or relative path of the file to inspect.
    Returns:
        A short string representing the detected format.
    """
    return detect_file_format(path)

async def tool_list_supported_formats() -> list[str]:
    """
    Name:
        List supported formats
    Description:
        List all file formats that can be used as input or output
        for format conversion.
    Returns:
        A list of supported format identifiers such as 'csv', 'json', 'xml', 'yaml'.
    """
    return list_supported_formats()

async def tool_preview_converted_content(input_path: str = Field(description="Absolute or relative path of the source file"),
    input_format: str = Field(
        description="Explicit input format (e.g. 'csv', 'json', 'xml', 'yaml'); "
                    "if empty, it will be inferred from input_path"
    ),
    output_format: str = Field(
        description="Target format for preview (e.g. 'json', 'yaml', 'csv')"
    ),
    max_lines: int = Field(
        default=50,
        description="Maximum number of lines or items to include in the preview"
    ),) -> str:
    """
    Name:
        Preview converted content
    Description:
        Convert a file in-memory and return only a small textual preview of the
        converted content, without writing anything to disk.
    Args:
        input_path: Absolute or relative path of the source file.
        input_format: Explicit input format (e.g. 'csv', 'json', 'xml', 'yaml');
            if empty, it will be inferred from input_path.
        output_format: Target format for preview (e.g. 'json', 'yaml', 'csv').
        max_lines: Maximum number of lines or items to include in the preview.
    Returns:
        A textual preview of the converted content.
    """
    return preview_converted_content(input_path, input_format, output_format, max_lines)
