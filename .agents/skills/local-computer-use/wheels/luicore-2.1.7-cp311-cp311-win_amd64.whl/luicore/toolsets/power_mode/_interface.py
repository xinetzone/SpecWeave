# coding: utf-8
from .tools import is_power_plugged_in, set_power_mode, get_current_power_mode


async def tool_set_power_mode(AC_plan_mode: int = -1, DC_plan_mode: int = -1) -> tuple[int, int, bool]:
    """
    Sets the Windows power mode/plan.
    Description:
        The function will attempt to change the power mode to the specified mode and return a message indicating the current power status and the result of the operation.

    Args:
        AC_plan_mode (int): The power mode to apply when plugged in. Valid values (default is -1):
            -1: No change (just choose it if you don't know what to choose.)
            0: Balanced (平衡)
            1: High Performance (最佳性能, 高性能)
            2: Power Saver (最佳能效, 省电, 节能)
        DC_plan_mode (int): The power plan to apply when on battery. Valid values (default is -1):
            -1: No change (just choose it if you don't know what to choose.)
            0: Balanced (平衡)
            1: High Performance (最佳性能, 高性能)
            2: Power Saver (最佳能效, 省电, 节能)

    Returns:
        tuple[int, int, bool]: A tuple of (AC_plan_mode, DC_plan_mode, plugging_in).
    """
    if AC_plan_mode == -1 and DC_plan_mode == -1:
        # If both parameters are -1, just return the current power status without changing the power plan.
        return await tool_get_current_power_mode()

    set_power_mode(AC_plan_mode, DC_plan_mode)
    return AC_plan_mode, DC_plan_mode, is_power_plugged_in()

async def tool_get_current_power_mode() -> tuple[int, int, bool]:
    """
    Gets the current Windows power mode/plan.

    Returns:
        tuple[int, int, bool]: A tuple of (AC_plan_mode, DC_plan_mode, plugging_in).
    """

    AC_plan_mode, DC_plan_mode = get_current_power_mode()
    return AC_plan_mode, DC_plan_mode, is_power_plugged_in()
