# coding: utf-8
from .tools import turn_magnifier_on, turn_magnifier_off, open_magnifier_settings_panel


# async def tool_turn_magnifier_on() -> bool:
#     """
#     Turns the Windows Magnifier on.
#
#     Args:
#         None
#
#     Returns:
#         bool: True if successful, False otherwise.
#     """
#     return turn_magnifier_on()
#
#
# async def tool_turn_magnifier_off() -> bool:
#     """
#     Turns the Windows Magnifier off.
#
#     Args:
#         None
#
#     Returns:
#         bool: True if successful, False otherwise.
#     """
#     return turn_magnifier_off()


async def tool_open_magnifier_settings_panel() -> bool:
    """
    Opens the Windows Magnifier settings panel.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return open_magnifier_settings_panel()
