# coding: utf-8
from pydantic import Field
from .tools import generate_id_photo, get_id_photo_presets, validate_id_photo


async def tool_generate_id_photo(image_path: str = Field(description="Path to the input portrait image"),
    output_path: str = Field(description="Path to save the generated ID photo"),
    width: int = Field(description="Target ID photo width in pixels"),
    height: int = Field(description="Target ID photo height in pixels"),
    background_color: str = Field(
        default="#FFFFFF",
        description="Background color in hex format (e.g. #FFFFFF for white)"
    ),
    dpi: int = Field(
        default=300,
        description="Target DPI (dots per inch) for the output ID photo"
    ),) -> str:
    """
    Name:
        Generate ID photo
    Description:
        Generate a standardized ID photo from an input portrait image with the specified size, background color, and DPI.
    Args:
        image_path: Path to the input portrait image.
        output_path: Path to save the generated ID photo.
        width: Target ID photo width in pixels.
        height: Target ID photo height in pixels.
        background_color: Background color in hex format.
        dpi: Target DPI for the output ID photo.
    Returns:
        The path of the generated ID photo.
    """
    return generate_id_photo(image_path, output_path, width, height, background_color, dpi)

async def tool_get_id_photo_presets() -> dict:
    """
    Name:
        Get ID photo presets
    Description:
        Get a list of common ID photo size presets for various document types and countries.
    Returns:
        A dictionary where keys are preset names (e.g. 'CN_ID_1INCH', 'US_PASSPORT')
        and values are objects containing width, height, and DPI.
    """
    return get_id_photo_presets()

async def tool_validate_id_photo(image_path: str = Field(description="Path to the ID photo image to validate"),
    preset_name: str = Field(description="Preset name to validate against"),) -> bool:
    """
    Name:
        Validate ID photo
    Description:
        Validate an existing ID photo against a given preset (size, aspect ratio, and DPI).
    Args:
        image_path: Path to the ID photo image to validate.
        preset_name: Preset name to validate against.
    Returns:
        True if the ID photo meets the preset requirements, otherwise False.
    """
    return validate_id_photo(image_path, preset_name)
