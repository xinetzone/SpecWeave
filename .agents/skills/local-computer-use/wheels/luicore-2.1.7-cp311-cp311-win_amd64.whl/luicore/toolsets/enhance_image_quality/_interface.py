# coding: utf-8
from pydantic import Field
from .tools import enhance_image_quality, get_image_quality_metrics


async def tool_enhance_image_quality(image_path: str = Field(description="Path to the input image file", default=""),
    output_path: str = Field(
        description="Path to save the enhanced image file. "
        "If empty, the original file will be overwritten.",
        default=""
    ),
    denoise_level: float = Field(
        description="Denoise strength, range 0.0-1.0 (0: no denoise, 1: strong denoise)",
        ge=0.0,
        le=1.0,
        default=0.3
    ),
    sharpen_level: float = Field(
        description="Sharpen strength, range 0.0-1.0 (0: no sharpen, 1: strong sharpen)",
        ge=0.0,
        le=1.0,
        default=0.4
    ),
    upscale_factor: float = Field(
        description="Upscale factor for the image size, e.g., 1.0 (no change), 2.0 (2x larger)",
        gt=0.0,
        default=1.0
    ),
    keep_metadata: bool = Field(
        description="Whether to preserve EXIF and other metadata in the output image",
        default=True
    ),) -> str:
    """
    Name:
        Enhance image quality
    Description:
        Enhance the quality of an image, including denoising, sharpening, and optional upscaling.
        The enhanced image will be saved to the specified output path or overwrite the input file.
    Args:
        image_path: Path to the input image file.
        output_path: Path to save the enhanced image; if empty, overwrite the original image.
        denoise_level: Denoise strength (0.0-1.0).
        sharpen_level: Sharpen strength (0.0-1.0).
        upscale_factor: Upscale factor (> 0.0), 1.0 means no size change.
        keep_metadata: Whether to preserve image metadata.
    Returns:
        The file path of the enhanced image.
    """
    return enhance_image_quality(image_path, output_path, denoise_level, sharpen_level, upscale_factor, keep_metadata)

async def tool_get_image_quality_metrics(image_path: str = Field(description="Path to the image file to analyze")) -> dict:
    """
    Name:
        Get image quality metrics
    Description:
        Analyze basic image quality metrics such as resolution, file size, and estimated sharpness/noise level.
    Args:
        image_path: Path to the image file.
    Returns:
        A dictionary containing image quality metrics, e.g.:
        {
            "width": int,
            "height": int,
            "file_size_bytes": int,
            "estimated_sharpness": float,
            "estimated_noise_level": float
        }
    """
    return get_image_quality_metrics(image_path)
