# coding: utf-8
from pydantic import Field
from .tools import batch_resize_portraits, batch_crop_portraits, batch_rename_portrait_files, list_portrait_files


async def tool_batch_resize_portraits(input_folder: str = Field(description="Path of the folder containing portrait images to be batch processed"),
    output_folder: str = Field(description="Path of the folder where processed portrait images will be saved"),
    target_width: int = Field(description="Target width of the output portraits in pixels"),
    target_height: int = Field(description="Target height of the output portraits in pixels"),
    keep_aspect_ratio: bool = Field(description="Whether to preserve original aspect ratio when resizing"),
    fill_color: str = Field(
        default="#000000",
        description="Fill color (e.g. '#RRGGBB') for padding when keeping aspect ratio and target size mismatches",
    ),
    overwrite_existing: bool = Field(
        default=False,
        description="Whether to overwrite files in the output folder when the same filename already exists",
    ),) -> bool:
    """
    Name:
        Batch resize portraits
    Description:
        Batch resize all portrait images from the input folder and save them to the output folder.
        Supports fixed target width and height, optional aspect ratio preservation, and optional padding color.
    Args:
        input_folder: Path of the folder containing portrait images to be batch processed.
        output_folder: Path of the folder where processed portrait images will be saved.
        target_width: Target width of the output portraits in pixels.
        target_height: Target height of the output portraits in pixels.
        keep_aspect_ratio: Whether to preserve original aspect ratio when resizing.
        fill_color: Fill color (e.g. '#RRGGBB') for padding when keeping aspect ratio and target size mismatches.
        overwrite_existing: Whether to overwrite files in the output folder when the same filename already exists.
    Returns:
        True on success, False on failure.
    """
    return batch_resize_portraits(input_folder, output_folder, target_width, target_height, keep_aspect_ratio, fill_color, overwrite_existing)

async def tool_batch_crop_portraits(input_folder: str = Field(description="Path of the folder containing portrait images to be batch cropped"),
    output_folder: str = Field(description="Path of the folder where cropped portrait images will be saved"),
    crop_left: int = Field(description="Number of pixels to crop from the left edge"),
    crop_top: int = Field(description="Number of pixels to crop from the top edge"),
    crop_right: int = Field(description="Number of pixels to crop from the right edge"),
    crop_bottom: int = Field(description="Number of pixels to crop from the bottom edge"),
    overwrite_existing: bool = Field(
        default=False,
        description="Whether to overwrite files in the output folder when the same filename already exists",
    ),) -> bool:
    """
    Name:
        Batch crop portraits
    Description:
        Batch crop all portrait images from the input folder with the specified crop margins and
        save them to the output folder.
    Args:
        input_folder: Path of the folder containing portrait images to be batch cropped.
        output_folder: Path of the folder where cropped portrait images will be saved.
        crop_left: Number of pixels to crop from the left edge.
        crop_top: Number of pixels to crop from the top edge.
        crop_right: Number of pixels to crop from the right edge.
        crop_bottom: Number of pixels to crop from the bottom edge.
        overwrite_existing: Whether to overwrite files in the output folder when the same filename already exists.
    Returns:
        True on success, False on failure.
    """
    return batch_crop_portraits(input_folder, output_folder, crop_left, crop_top, crop_right, crop_bottom, overwrite_existing)

async def tool_batch_rename_portrait_files(input_folder: str = Field(description="Path of the folder containing portrait images to be renamed"),
    name_pattern: str = Field(
        description="New filename pattern, e.g. 'portrait_{index:03d}.png'; "
        "the pattern should contain an 'index' placeholder"
    ),
    start_index: int = Field(default=1, description="Starting index for renaming"),
    overwrite_existing: bool = Field(
        default=False,
        description="Whether to overwrite existing files when the new name already exists",
    ),) -> bool:
    """
    Name:
        Batch rename portrait files
    Description:
        Batch rename all portrait images in the input folder using a numeric pattern.
        Supports a configurable starting index and optional overwriting behavior.
    Args:
        input_folder: Path of the folder containing portrait images to be renamed.
        name_pattern: New filename pattern, e.g. 'portrait_{index:03d}.png'; must contain an 'index' placeholder.
        start_index: Starting index for renaming.
        overwrite_existing: Whether to overwrite existing files when the new name already exists.
    Returns:
        True on success, False on failure.
    """
    return batch_rename_portrait_files(input_folder, name_pattern, start_index, overwrite_existing)

async def tool_list_portrait_files(folder: str = Field(description="Path of the folder to scan for portrait image files"),
    include_subfolders: bool = Field(
        default=False,
        description="Whether to recursively include portrait images from subfolders",
    ),
    extensions: str = Field(
        default=".png,.jpg,.jpeg,.bmp",
        description="Comma-separated list of file extensions to consider as portrait images",
    ),) -> list[str]:
    """
    Name:
        List portrait files
    Description:
        List portrait image files in the specified folder, optionally including subfolders
        and filtering by extension.
    Args:
        folder: Path of the folder to scan for portrait image files.
        include_subfolders: Whether to recursively include portrait images from subfolders.
        extensions: Comma-separated list of file extensions to consider as portrait images.
    Returns:
        A list of absolute file paths to portrait images.
    """
    return list_portrait_files(folder, include_subfolders, extensions)
