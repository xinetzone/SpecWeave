# coding: utf-8
from .tools import open_control_panel


async def tool_open_control_panel() -> bool:
    """
    Opens the Windows Control Panel.

    Args:
        None

    Returns:
        bool: True if the Control Panel was opened successfully, False otherwise.
    """
    return open_control_panel()
