# coding: utf-8
from .tools import open_firewall_advanced_settings


async def tool_open_firewall_advanced_settings() -> bool:
    """
    Opens the Windows Firewall advanced settings.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return open_firewall_advanced_settings()