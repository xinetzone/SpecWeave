# coding: utf-8
from pydantic import Field
from .tools import preview_batch_rename, execute_batch_rename, revert_batch_rename, list_batch_rename_history


from typing import List

async def tool_preview_batch_rename() -> bool:
    """
    Name:
        Preview batch rename
    Description:
        Generate a preview of batch file renaming operations without modifying the filesystem.
        Returns a list of planned rename operations.
    Returns:
        List of rename operations as dicts with keys:
            'original_path', 'original_name', 'new_path', 'new_name'.
    """
    return preview_batch_rename()

async def tool_execute_batch_rename(directory: str = Field(description="Target directory containing files to be renamed"),
    pattern: str = Field(description="Original filename pattern or wildcard (e.g. '*.txt' or 'IMG_*.jpg')"),
    rename_template: str = Field(
        description=(
            "Template for new filenames. May contain placeholders like "
            "'{index}', '{name}', '{ext}'. Example: 'Document_{index:03d}{ext}'"
        )
    ),
    recursive: bool = Field(
        default=False,
        description="Whether to search for matching files in subdirectories recursively",
    ),
    overwrite: bool = Field(
        default=False,
        description="Whether to overwrite existing files when new filenames already exist",
    ),
    simulate: bool = Field(
        default=False,
        description="If True, validate and return operations without actually renaming any files",
    ),) -> List[dict]:
    """
    Name:
        Execute batch rename
    Description:
        Perform batch file renaming operations based on the specified pattern and template.
        Can optionally run in simulation mode to validate operations without changing files.
    Args:
        directory: Target directory containing files to be renamed.
        pattern: Original filename pattern or wildcard (e.g. '*.txt' or 'IMG_*.jpg').
        rename_template: Template for new filenames. May contain placeholders like
            '{index}', '{name}', '{ext}'. Example: 'Document_{index:03d}{ext}'.
        recursive: Whether to search for matching files in subdirectories recursively.
        overwrite: Whether to overwrite existing files when new filenames already exist.
        simulate: If True, validate and return operations without renaming any files.
    Returns:
        List of executed or planned rename operations as dicts with keys:
            'original_path', 'original_name', 'new_path', 'new_name', 'status', 'error'.
    """
    return execute_batch_rename(directory, pattern, rename_template, recursive, overwrite, simulate)

async def tool_revert_batch_rename(history_id: str = Field(description="Identifier of a previous batch rename operation to revert"),) -> bool:
    """
    Name:
        Revert batch rename
    Description:
        Revert a previous batch rename operation identified by a history ID.
        Returns True on success, False on failure.
    Args:
        history_id: Identifier of the batch rename operation to revert.
    Returns:
        True on success, False on failure.
    """
    return revert_batch_rename(history_id)

async def tool_list_batch_rename_history(limit: int = Field(default=20, description="Maximum number of history entries to return"),) -> List[dict]:
    """
    Name:
        List batch rename history
    Description:
        List recent batch rename operations for potential review or revert.
    Args:
        limit: Maximum number of history entries to return.
    Returns:
        List of history entries as dicts with keys such as:
            'history_id', 'timestamp', 'directory', 'pattern', 'rename_template',
            'file_count', 'status'.
    """
    return list_batch_rename_history(limit)
