# coding: utf-8
from .tools import get_memory_frequency


async def tool_get_memory_frequency() -> str:
    """
    Gets the current memory speed.

    Returns:
        str: The memory speed, for example: "内存速度：7467 MT/秒".
    """
    return get_memory_frequency()
