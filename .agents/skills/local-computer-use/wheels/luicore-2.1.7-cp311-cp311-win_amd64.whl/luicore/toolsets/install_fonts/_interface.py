# coding: utf-8
from .tools import open_fonts_install_panel


async def tool_open_fonts_install_panel() -> bool:
    """
    Opens the font installation settings panel to install new fonts.

    Args:
        None.

    Returns:
        bool: True if the panel was opened successfully, False otherwise.
    """
    return open_fonts_install_panel()
