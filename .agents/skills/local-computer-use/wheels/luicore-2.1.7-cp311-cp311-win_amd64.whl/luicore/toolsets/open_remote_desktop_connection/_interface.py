# coding: utf-8
from .tools import open_remote_desktop_connection


async def tool_open_remote_desktop_connection() -> bool:
    """
    Opens the Windows Remote Desktop Connection client.

    Args:
        None

    Returns:
        bool: True if the Remote Desktop Connection client was opened successfully, False otherwise.
    """
    return open_remote_desktop_connection()
