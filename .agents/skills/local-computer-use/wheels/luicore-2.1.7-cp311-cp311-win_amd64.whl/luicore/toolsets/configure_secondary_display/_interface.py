# coding: utf-8
from .tools import open_secondary_display_settings_panel


async def tool_open_secondary_display_settings_panel() -> bool:
    """
    Opens the Windows "Display settings" panel so the user can configure a secondary monitor.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return open_secondary_display_settings_panel()