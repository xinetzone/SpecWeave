# coding: utf-8
from .tools import create_user_account


async def tool_create_user_account() -> bool:
    """
    Creates a new user account.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return create_user_account()
