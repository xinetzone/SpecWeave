# coding: utf-8
from .tools import open_apps_and_features


async def tool_open_apps_and_features() -> bool:
    """
    Opens the Windows "Apps & features" settings page.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return open_apps_and_features()