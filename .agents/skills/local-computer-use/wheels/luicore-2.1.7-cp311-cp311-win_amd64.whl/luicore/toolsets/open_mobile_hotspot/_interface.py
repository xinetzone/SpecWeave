# coding: utf-8
from .tools import open_mobile_hotspot_settings


async def tool_open_mobile_hotspot_settings() -> bool:
    """
    Opens the Windows mobile hotspot settings.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return open_mobile_hotspot_settings()
