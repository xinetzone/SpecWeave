# coding: utf-8
from .tools import is_microphone_device_available, set_microphone_status


async def tool_is_microphone_available() -> bool:
    '''
    Name: Is Microphone Available
    Description: Checks if a microphone device is available on the system.
    Returns:
        bool: True if a microphone device is available, False otherwise.
    '''
    return is_microphone_device_available()

async def tool_set_microphone_status(enabled: bool) -> bool:
    '''
    Name: Set Microphone Status
    Description: Enables or disables the microphone.
    Parameters:
        enabled (bool): True to enable the microphone, False to disable it.
    Returns:
        bool: True if the operation was successful, False otherwise.
    '''
    return set_microphone_status(enabled)

async def tool_who_is_using_microphone() -> list[str]|None:
    '''
    Name: Who Is Using Microphone
    Description: Gets the names of the applications currently using the microphone.
    Returns:
        list[str]|None: 
         A list of the names of the applications using the microphone, or None if no microphone device is available.
    '''
    return None
