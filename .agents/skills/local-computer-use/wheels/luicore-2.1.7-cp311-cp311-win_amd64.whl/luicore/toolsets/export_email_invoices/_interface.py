# coding: utf-8
from pydantic import Field
from .tools import export_email_invoices, list_email_invoices, get_email_invoice_status


from typing import List

async def tool_export_email_invoices() -> bool:
    """
    Name:
        Export email invoices
    Description:
        Export email-ready invoice documents for the specified date range and optional customer filter.
        Returns True on success, False on failure.
    Returns:
        True on success, False on failure.
    """
    return export_email_invoices()

async def tool_list_email_invoices() -> List[dict]:
    """
    Name:
        List email invoices
    Description:
        List invoices in the specified date range and optional customer filter,
        optionally restricted to invoices pending export/email.
    Returns:
        A list of invoice metadata objects (e.g., invoice number, customer, date, amount, status).
    """
    return list_email_invoices()

async def tool_get_email_invoice_status(invoice_number: str = Field(description="Invoice number to query"),) -> str:
    """
    Name:
        Get email invoice status
    Description:
        Get the export/email status for the specified invoice.
    Args:
        invoice_number: Invoice number to query.
    Returns:
        A status string such as 'pending', 'exported', 'emailed', or 'failed'.
    """
    return get_email_invoice_status(invoice_number)
