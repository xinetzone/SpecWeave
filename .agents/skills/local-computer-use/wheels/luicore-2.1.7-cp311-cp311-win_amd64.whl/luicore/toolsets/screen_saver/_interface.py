# coding: utf-8
from .tools import disable_screen_saver, show_screen_saver_settings


async def tool_disable_screen_saver() -> bool:
    """
    Disables the Windows screen saver by updating the related system settings.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return disable_screen_saver()

async def tool_show_screen_saver() -> bool:
    """
    Opens the Windows screen saver settings panel.

    Args:
        None
    Returns:
        bool: True if successful, False otherwise.
    """
    return show_screen_saver_settings()