# coding: utf-8
from .tools import get_hard_drive_serial_number


async def tool_get_hard_drive_serial_number() -> list:
    """
    Retrieves the computer hard drive serial number.

    Args:
        None

    Returns:
        list: A structured payload containing the computer hard drive information.
    """
    return get_hard_drive_serial_number()