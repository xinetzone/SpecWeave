# coding: utf-8
from .tools import pause_windows_auto_update, resume_windows_auto_update, get_windows_auto_update_status


async def tool_pause_windows_auto_update(weeks) -> str:
    """
    Sets the Windows Update pause duration.

    Args:
        weeks (int): Number of weeks to pause updates. 0 resumes normal updates,
            1–5 pauses updates for the given number of weeks. Any other value
            leaves the pause duration unchanged.

    Returns:
        str: A message indicating the result of the operation.
    """
    return pause_windows_auto_update(weeks)

async def tool_resume_windows_auto_update() -> bool:
    """
    Resumes Windows automatic updates immediately.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return resume_windows_auto_update()

async def tool_get_windows_auto_update_status() -> str:
    """
    Gets the current status of Windows automatic updates.

    Args:
        None

    Returns:
        str: A string describing the current Windows automatic update status,
            such as whether updates are enabled, paused (and until when), or
            disabled by policy.
    """
    return get_windows_auto_update_status()
