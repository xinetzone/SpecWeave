# coding: utf-8
from .tools import change_admin_account


async def tool_change_admin_account() -> bool:
    """
    Changes administrator account settings, such as modifying the administrator password,
    deleting the administrator account, or updating administrator account information.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return change_admin_account()
