@echo off
setlocal enabledelayedexpansion

start C:\Windows\System32\msdt.exe /id networkdiagnosticsnetworkadapter

endlocal