# coding: utf-8
from .tools import open_network_troubleshooter


async def tool_open_network_troubleshooter() -> bool:
    """
    Opens the Windows network troubleshooter.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return open_network_troubleshooter()
