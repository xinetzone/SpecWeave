# coding: utf-8
from .tools import get_graphics_cards


async def tool_get_graphics_cards() -> list:
    """
    Queries the graphics cards installed on this computer.

    Returns:
        list: A structured payload listing detected GPUs.
    """
    return get_graphics_cards()
