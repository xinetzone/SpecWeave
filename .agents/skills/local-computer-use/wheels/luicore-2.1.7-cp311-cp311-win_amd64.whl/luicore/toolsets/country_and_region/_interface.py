# coding: utf-8
from .tools import get_current_region, set_region_by_name


async def tool_get_current_region() -> str:
    """
    Gets the current country or region configured on this computer.

    Args:
        None

    Returns:
        str: The name of the current country or region, for example "中国", "美国", etc.
    """
    return get_current_region()

async def tool_set_region(region_name: str = "中国") -> bool:
    """
    Sets the current country or region on this computer.

    Args:
        region_name (str): The country or region name to set, for example "中国", "美国", etc.

    Returns:
        bool: True if the region was set successfully, False otherwise.
    """
    return set_region_by_name(region_name)
