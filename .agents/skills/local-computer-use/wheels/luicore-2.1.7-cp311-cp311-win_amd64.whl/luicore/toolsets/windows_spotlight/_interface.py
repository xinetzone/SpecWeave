# coding: utf-8
from .tools import switch_windows_spotlight_for_lockscreen


async def tool_windows_spotlight_for_lockscreen(enable: bool) -> bool:
    """
    Enables or disables Windows Spotlight on the lock screen.

    Args:
        enable (bool): True to enable Windows Spotlight; False to disable it.

    Returns:
        bool: True if the operation was successful, False otherwise.
    """
    return switch_windows_spotlight_for_lockscreen(enable)

