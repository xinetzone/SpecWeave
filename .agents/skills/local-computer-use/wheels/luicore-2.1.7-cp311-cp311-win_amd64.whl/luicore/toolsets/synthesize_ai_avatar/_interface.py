# coding: utf-8
from pydantic import BaseModel, Field
from .tools import list_available_avatar_models, list_available_voices, synthesize_ai_avatar_from_text, get_avatar_last_synthesis_status, cancel_avatar_synthesis


from typing import List, Optional

async def tool_list_available_avatar_models() -> List[str]:
    """
    Name:
        List available avatar models
    Description:
        列出当前可用于驱动数字人的头像/模型 ID 列表。
    Returns:
        模型 ID 列表，例如 ["avatar_default_female", "avatar_default_male"]。
    """
    return list_available_avatar_models()

async def tool_list_available_voices(language: Optional[str] = Field(
    default=None,
    description="可选，按语言过滤，如 'en-US' 或 'zh-CN'。若为空则返回所有可用语音。"
)) -> List[str]:
    """
    Name:
        List available voices
    Description:
        列出当前可用的 TTS 语音名称或 ID，可以根据语言进行过滤。
    Args:
        language: 语言编码（可选），例如 'en-US', 'zh-CN'。
    Returns:
        语音名称/ID 列表。
    """
    return list_available_voices(language)

async def tool_synthesize_ai_avatar_from_text(text: str = Field(description="用于驱动数字人说话的文本内容")) -> bool:
    """
    Name:
        Synthesize AI avatar from text
    Description:
        通过文本 + 语音配置 + 视频配置合成带有 AI 数字人的视频。
    Args:
        text: 文本内容。
    """
    return synthesize_ai_avatar_from_text(text)

async def tool_get_avatar_last_synthesis_status(task_id: str = Field(description="合成任务 ID")) -> bool:
    """
    Name:
        Get avatar last synthesis status
    Description:
        根据任务 ID 查询最近一次数字人视频合成任务的状态与结果。
    Args:
        task_id: 合成任务 ID。
    Returns:
        合成结果信息，包含成功标记、视频路径、错误信息等。
    """
    return get_avatar_last_synthesis_status(task_id)

async def tool_cancel_avatar_synthesis(task_id: str = Field(description="要取消的合成任务 ID")) -> bool:
    """
    Name:
        Cancel avatar synthesis
    Description:
        取消一个尚未完成的数字人视频合成任务。
    Args:
        task_id: 合成任务 ID。
    Returns:
        True 表示请求取消已提交，False 表示取消失败或任务不存在。
    """
    return cancel_avatar_synthesis(task_id)
