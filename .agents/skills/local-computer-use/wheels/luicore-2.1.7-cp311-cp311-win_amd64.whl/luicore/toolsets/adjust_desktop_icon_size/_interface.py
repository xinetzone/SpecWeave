# coding: utf-8
from .tools import set_desktop_icon_size, make_desktop_icon_size_larger, make_desktop_icon_size_smaller


async def tool_set_desktop_icon_size(size: str = "中等图标") -> str:
    """
    Sets the Windows desktop icon size.

    Args:
        size (str): The icon size. Valid values: "大图标", "中等图标", "小图标". Default value is "中等图标".

    Returns:
        str: Description of new desktop icon size after the operation.
    """
    return set_desktop_icon_size(size)

async def tool_make_desktop_icon_size_larger() -> str:
    """
    Make the icon size one level larger.

    Returns:
        str: Description of new desktop icon size after the operation.
    """
    return make_desktop_icon_size_larger()

async def tool_make_desktop_icon_size_smaller() -> str:
    """
    Make the icon size one level smaller.

    Returns:
        str: Description of new desktop icon size after the operation.
    """
    return make_desktop_icon_size_smaller()
