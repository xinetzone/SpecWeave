# coding: utf-8
from .tools import open_windows_update_settings


async def tool_open_windows_update_settings() -> bool:
    """
    Opens the Windows Update settings panel.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return open_windows_update_settings()