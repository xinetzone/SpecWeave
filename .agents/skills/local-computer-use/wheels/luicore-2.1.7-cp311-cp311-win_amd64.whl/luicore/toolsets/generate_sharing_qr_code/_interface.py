# coding: utf-8
from pydantic import Field
from .tools import generate_sharing_qr_code, get_sharing_qr_code_status, invalidate_sharing_qr_code


async def tool_generate_sharing_qr_code(content: str = Field(description="The text or URL to encode into the QR code"),
    size: int = Field(default=256, description="The width/height of the QR code image in pixels"),
    error_correction_level: str = Field(
        default="M",
        description="QR error correction level: one of L, M, Q, H"
    ),
    include_border: bool = Field(
        default=True,
        description="Whether to include a quiet-zone border around the QR code"
    ),
    image_format: str = Field(
        default="png",
        description="Output image format, e.g. png or jpg"
    )) -> str:
    """
    Name:
        Generate sharing QR code
    Description:
        Generate a QR code image for the given content and return a handle to the generated image.
    Args:
        content: The text or URL to encode into the QR code.
        size: The width/height of the QR code image in pixels.
        error_correction_level: QR error correction level: one of L, M, Q, H.
        include_border: Whether to include a quiet-zone border around the QR code.
        image_format: Output image format, e.g. png or jpg.
    Returns:
        An identifier, file path, or URL pointing to the generated QR code image.
    """
    return generate_sharing_qr_code(content, size, error_correction_level, include_border, image_format)

async def tool_get_sharing_qr_code_status(qr_id: str = Field(description="Identifier of a previously requested QR code")) -> str:
    """
    Name:
        Get sharing QR code status
    Description:
        Query the generation status or metadata of a previously requested QR code.
    Args:
        qr_id: Identifier of a previously requested QR code.
    Returns:
        A status string or serialized metadata (e.g. JSON) describing the QR code and its availability.
    """
    return get_sharing_qr_code_status(qr_id)

async def tool_invalidate_sharing_qr_code(qr_id: str = Field(description="Identifier of the QR code to invalidate or revoke")) -> bool:
    """
    Name:
        Invalidate sharing QR code
    Description:
        Invalidate or revoke a previously generated sharing QR code so it can no longer be used.
    Args:
        qr_id: Identifier of the QR code to invalidate or revoke.
    Returns:
        True on success, False on failure.
    """
    return invalidate_sharing_qr_code(qr_id)
