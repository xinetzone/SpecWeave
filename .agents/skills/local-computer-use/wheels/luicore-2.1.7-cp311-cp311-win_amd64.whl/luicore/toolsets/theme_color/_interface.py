# coding: utf-8
from .tools import enable_dark_mode, enable_light_mode


async def tool_enable_dark_mode() -> str:
    """
    Sets the Windows and default app color theme to dark mode/深色模式.

    Args:
        None

    Returns:
        str: The result message after attempting to enable dark mode.
    """
    return enable_dark_mode()

async def tool_enable_light_mode() -> str:
    """
    Sets the Windows and default app color theme to light mode/浅色模式.

    Args:
        None

    Returns:
        str: The result message from the enable_light_mode operation.
    """
    return enable_light_mode()