# coding: utf-8
from .tools import start_speech_recognition, stop_speech_recognition, open_speech_recognition_settings_panel


async def tool_open_speech_recognition_settings_panel() -> bool:
    """
    Opens the system speech recognition settings panel.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return open_speech_recognition_settings_panel()

# async def tool_stop_speech_recognition() -> bool:
#     """
#     Stops the current speech recognition session.
#
#     Args:
#         None
#
#     Returns:
#         bool: True if successful, False otherwise.
#     """
#     return stop_speech_recognition()
#
# async def tool_start_speech_recognition() -> bool:
#     """
#     Starts the speech recognition feature.
#
#     Args:
#         None
#
#     Returns:
#         bool: True if successful, False otherwise.
#     """
#     return start_speech_recognition()
