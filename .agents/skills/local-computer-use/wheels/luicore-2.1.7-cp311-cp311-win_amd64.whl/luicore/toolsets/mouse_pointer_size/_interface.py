# coding: utf-8
from .tools import get_mouse_pointer_size, set_mouse_pointer_size, open_mouse_pointer_size_settings


async def tool_get_mouse_pointer_size() -> int:
    """
    Gets the current mouse pointer/指针/光标 size.

    Args:
        None

    Returns:
        int: The current mouse pointer size.
    """
    return get_mouse_pointer_size()

async def tool_set_mouse_pointer_size(size: int = 1) -> bool:
    """
    Sets the mouse pointer/指针/光标 size.

    Args:
        size (int): The size value of mouse pointer/指针/光标, from 1 to 15, default is 1 (the smallest).

    Returns:
        bool: True if the operation was successful, False otherwise.
    """
    return set_mouse_pointer_size(size)

async def tool_open_mouse_pointer_size_settings() -> bool:
    """
    Opens the Windows mouse pointer/指针/光标 size settings page.

    Args:
        None

    Returns:
        bool: True if the settings page was opened successfully, False otherwise.
    """
    return open_mouse_pointer_size_settings()