# coding: utf-8
from .tools import set_news_and_interests


async def tool_enable_news_and_interests(enable: bool) -> bool:
    """
    Enables or disables the Windows taskbar News and Interests feature.

    Args:
        enable (bool): True to enable the feature, False to disable it.

    Returns:
        bool: True if successful, False otherwise.
    """
    return set_news_and_interests(enable)
