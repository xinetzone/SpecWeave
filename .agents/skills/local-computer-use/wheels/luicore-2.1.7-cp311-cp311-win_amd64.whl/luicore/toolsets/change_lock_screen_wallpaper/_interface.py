# coding: utf-8
from .tools import set_lock_screen_wallpaper


async def tool_set_lock_screen_wallpaper(image_path: str = "") -> str:
    """
    Sets the Windows lock screen wallpaper to the specified image.

    Args:
        image_path (str): Absolute file path of the image to use for the lock screen wallpaper.

    Returns:
        str: Result message indicating success or failure.
    """
    return set_lock_screen_wallpaper(image_path)
