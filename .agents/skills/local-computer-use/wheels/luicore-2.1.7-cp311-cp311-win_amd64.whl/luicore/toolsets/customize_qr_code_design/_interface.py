# coding: utf-8
from pydantic import Field
from .tools import generate_qr_code, preview_qr_design, list_qr_presets, apply_qr_preset


async def tool_generate_qr_code(data: str = Field(description="The content to be encoded into the QR code"),
    version: int = Field(
        default=1,
        ge=1,
        le=40,
        description="QR Code version (1-40), controls size and capacity"
    ),
    error_correction: str = Field(
        default="M",
        description="Error correction level: one of 'L', 'M', 'Q', 'H'"
    ),
    box_size: int = Field(
        default=10,
        ge=1,
        description="Pixel size of each QR module (box)"
    ),
    border: int = Field(
        default=4,
        ge=0,
        description="Border width (in modules) around the QR code"
    ),
    foreground_color: str = Field(
        default="#000000",
        description="Foreground color in hex format (e.g. '#000000' for black)"
    ),
    background_color: str = Field(
        default="#FFFFFF",
        description="Background color in hex format (e.g. '#FFFFFF' for white)"
    ),
    logo_path: str | None = Field(
        default=None,
        description="Optional path to a logo image to embed at the center of the QR code"
    ),
    logo_scale: float = Field(
        default=0.2,
        gt=0.0,
        lt=1.0,
        description="Relative size of the logo compared to the QR code (0-1)"
    ),
    output_format: str = Field(
        default="png",
        description="Output image format, e.g. 'png', 'jpg', 'svg'"
    ),) -> str:
    """
    Name:
        Generate customized QR code
    Description:
        Generate a customized QR code image with given content, colors, size, error
        correction level and optional embedded logo. Returns the file path of the
        generated QR code image.
    Args:
        data: The content to be encoded into the QR code.
        version: QR Code version (1-40), controls size and capacity.
        error_correction: Error correction level: one of 'L', 'M', 'Q', 'H'.
        box_size: Pixel size of each QR module (box).
        border: Border width (in modules) around the QR code.
        foreground_color: Foreground color in hex format.
        background_color: Background color in hex format.
        logo_path: Optional path to a logo image to embed at the center of the QR code.
        logo_scale: Relative size of the logo compared to the QR code (0-1).
        output_format: Output image format, e.g. 'png', 'jpg', 'svg'.
    Returns:
        The file path of the generated QR code image.
    """
    return generate_qr_code(data, version, error_correction, box_size, border, foreground_color, background_color, logo_path, logo_scale, output_format)

async def tool_preview_qr_design(data: str = Field(description="The content to be encoded into the QR code"),
    foreground_color: str = Field(
        default="#000000",
        description="Foreground color in hex format used for preview"
    ),
    background_color: str = Field(
        default="#FFFFFF",
        description="Background color in hex format used for preview"
    ),
    with_logo: bool = Field(
        default=False,
        description="Whether to assume a logo will be embedded in the center for preview purposes"
    ),) -> str:
    """
    Name:
        Preview QR code design
    Description:
        Generate a low-resolution preview representation of the QR code design using
        the given content and basic color settings. Intended for quick design
        iteration. Returns a preview identifier or preview file path.
    Args:
        data: The content to be encoded into the QR code.
        foreground_color: Foreground color in hex format used for preview.
        background_color: Background color in hex format used for preview.
        with_logo: Whether to assume a logo will be embedded in the center.
    Returns:
        A string representing the preview identifier or preview file path.
    """
    return preview_qr_design(data, foreground_color, background_color, with_logo)

async def tool_list_qr_presets() -> list[str]:
    """
    Name:
        List QR design presets
    Description:
        List available QR code design presets (predefined color schemes, versions
        and styles) that can be applied when generating QR codes.
    Returns:
        A list of preset names that can be used with 'Apply QR design preset'.
    """
    return list_qr_presets()

async def tool_apply_qr_preset(preset_name: str = Field(description="The name of the QR design preset to apply"),) -> dict:
    """
    Name:
        Apply QR design preset
    Description:
        Apply a predefined QR code design preset by name and return its configuration
        parameters such as version, error correction, colors and logo settings.
    Args:
        preset_name: The name of the QR design preset to apply.
    Returns:
        A dictionary containing the preset configuration parameters.
    """
    return apply_qr_preset(preset_name)
