# coding: utf-8
from .tools import get_pc_serial_number


async def tool_get_pc_serial_number() -> list:
    """
    Gets the PC serial number (S/N).

    Args:
        None

    Returns:
        list: A structured payload containing the PC serial number.
    """
    return get_pc_serial_number()