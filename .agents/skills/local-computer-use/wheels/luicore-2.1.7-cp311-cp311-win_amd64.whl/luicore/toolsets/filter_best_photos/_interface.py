# coding: utf-8
from pydantic import Field
from .tools import filter_best_photos, score_photo, get_photo_metadata, find_similar_photos, group_photos_by_scene


async def tool_filter_best_photos(folder_path: str = Field(description="Folder path containing photos to evaluate"),
    top_k: int = Field(description="Number of best photos to select, e.g., 5"),
    recursive: bool = Field(
        default=False,
        description="Whether to search photos recursively in subfolders",
    ),) -> list[str]:
    """
    Name:
        Filter best photos in folder
    Description:
        Analyze all photos in the specified folder and return the paths of the top K best photos
        according to quality metrics (e.g., sharpness, exposure, face quality).
    Args:
        folder_path: Folder path containing photos to evaluate.
        top_k: Number of best photos to select.
        recursive: Whether to search photos recursively in subfolders.
    Returns:
        A list of file paths of the selected best photos.
    """
    return filter_best_photos(folder_path, top_k, recursive)

async def tool_score_photo(image_path: str = Field(description="Full path of the photo to score")) -> float:
    """
    Name:
        Score single photo
    Description:
        Analyze a single photo and return a quality score. Higher scores indicate better photos.
    Args:
        image_path: Full path of the photo to score.
    Returns:
        A floating-point quality score of the photo.
    """
    return score_photo(image_path)

async def tool_get_photo_metadata(image_path: str = Field(description="Full path of the photo to read metadata from")) -> dict:
    """
    Name:
        Get photo metadata
    Description:
        Read and return metadata of the specified photo, such as resolution, EXIF info, shooting time,
        camera model, and exposure parameters.
    Args:
        image_path: Full path of the photo to read metadata from.
    Returns:
        A dictionary containing metadata key-value pairs.
    """
    return get_photo_metadata(image_path)

async def tool_find_similar_photos(reference_image_path: str = Field(description="Reference photo path"),
    folder_path: str = Field(description="Folder path containing photos to search"),
    similarity_threshold: float = Field(
        default=0.8,
        description="Similarity threshold between 0 and 1. Higher means more similar.",
    ),) -> list[str]:
    """
    Name:
        Find similar photos
    Description:
        Given a reference photo, search the specified folder for visually similar photos and
        return paths of photos whose similarity is above the given threshold.
    Args:
        reference_image_path: Reference photo path.
        folder_path: Folder path containing photos to search.
        similarity_threshold: Similarity threshold between 0 and 1.
    Returns:
        A list of file paths of similar photos.
    """
    return find_similar_photos(reference_image_path, folder_path, similarity_threshold)

async def tool_group_photos_by_scene(folder_path: str = Field(description="Folder path containing photos to group"),
    recursive: bool = Field(
        default=False,
        description="Whether to search photos recursively in subfolders",
    ),) -> dict:
    """
    Name:
        Group photos by scene
    Description:
        Analyze photos in the specified folder and group them into scenes/events,
        returning clusters keyed by scene identifiers.
    Args:
        folder_path: Folder path containing photos to group.
        recursive: Whether to search photos recursively in subfolders.
    Returns:
        A dictionary where keys are scene IDs or names and values are lists of photo paths.
    """
    return group_photos_by_scene(folder_path, recursive)
