# coding: utf-8
from .tools import open_pin_setting


async def tool_open_pin_setting() -> bool:
    """
    Opens the Windows PIN settings panel.
    User can then set up or change or remove their PIN from there.

    Args:
        None

    Returns:
        bool: True if the panel was opened successfully, False otherwise.
    """
    return open_pin_setting()