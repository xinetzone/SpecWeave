# coding: utf-8
from .tools import is_battery_available, get_battery_info, open_battery_settings


async def tool_get_battery_info() -> tuple[bool, dict]:
    '''
    Get battery information, including design capacity, full charge capacity, cycle count, and battery health.
    获取电池信息，包括设计容量、完全充电容量、循环次数和电池健康度。

    Args:
        None
    Returns:
        tuple[bool, dict]: A tuple of (is_battery_available, battery_info dict).
    '''
    if not is_battery_available():
        return (False, {})

    return (True, get_battery_info())
