# coding: utf-8
from .tools import open_command_prompt


async def tool_open_command_prompt() -> bool:
    """
    Opens the command prompt.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return open_command_prompt()
