# coding: utf-8
from .tools import open_disk_management, open_disk_cleanup


async def tool_open_disk_management() -> bool:
    """
    Opens the Windows Disk Management tool.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return open_disk_management()


async def tool_open_disk_cleanup() -> bool:
    """
    Opens the Windows Disk Cleanup tool.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return open_disk_cleanup()