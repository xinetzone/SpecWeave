# coding: utf-8
from pydantic import Field
from .tools import export_posts, export_comments, export_to_file

from typing import List

async def tool_export_posts(platform: str = Field(description="Target social media platform, e.g. 'twitter', 'facebook', 'instagram'"),
    account_id: str = Field(description="Unique identifier or handle of the social media account"),
    since: str = Field(description="Start datetime (inclusive) in ISO 8601 format, e.g. '2024-01-01T00:00:00Z'"),
    until: str = Field(description="End datetime (exclusive) in ISO 8601 format, e.g. '2024-01-31T00:00:00Z'"),
    include_comments: bool = Field(
        default=False,
        description="Whether to also export comments/replies associated with each post"
    ),
    include_metrics: bool = Field(
        default=True,
        description="Whether to export engagement metrics for each post (likes, shares, impressions, etc.)"
    ),) -> List[dict]:
    """
    Name:
        Export posts
    Description:
        Export posts for a given social media account on a specific platform within a time range.
    Args:
        platform: Target social media platform, e.g. 'twitter', 'facebook', 'instagram'.
        account_id: Unique identifier or handle of the social media account.
        since: Start datetime (inclusive) in ISO 8601 format.
        until: End datetime (exclusive) in ISO 8601 format.
        include_comments: Whether to also export comments/replies associated with each post.
        include_metrics: Whether to export engagement metrics for each post.
    Returns:
        A list of objects describing exported posts and optional comments/metrics.
    """
    return export_posts(platform, account_id, since, until, include_comments, include_metrics)

async def tool_export_comments(platform: str = Field(description="Target social media platform, e.g. 'twitter', 'facebook', 'instagram'"),
    account_id: str = Field(description="Unique identifier or handle of the social media account"),
    since: str = Field(description="Start datetime (inclusive) in ISO 8601 format, e.g. '2024-01-01T00:00:00Z'"),
    until: str = Field(description="End datetime (exclusive) in ISO 8601 format, e.g. '2024-01-31T00:00:00Z'"),
    include_commenter_profile: bool = Field(
        default=False,
        description="Whether to include basic profile information for commenters"
    ),) -> List[dict]:
    """
    Name:
        Export comments
    Description:
        Export comments/replies for all posts of a given social media account on a specific platform
        within a time range.
    Args:
        platform: Target social media platform, e.g. 'twitter', 'facebook', 'instagram'.
        account_id: Unique identifier or handle of the social media account.
        since: Start datetime (inclusive) in ISO 8601 format.
        until: End datetime (exclusive) in ISO 8601 format.
        include_commenter_profile: Whether to include basic profile information for commenters.
    Returns:
        A list of objects describing exported comments and optional commenter profile data.
    """
    return export_comments(platform, account_id, since, until, include_commenter_profile)

async def tool_export_to_file(platform: str = Field(description="Target social media platform, e.g. 'twitter', 'facebook', 'instagram'"),
    account_id: str = Field(description="Unique identifier or handle of the social media account"),
    since: str = Field(description="Start datetime (inclusive) in ISO 8601 format, e.g. '2024-01-01T00:00:00Z'"),
    until: str = Field(description="End datetime (exclusive) in ISO 8601 format, e.g. '2024-01-31T00:00:00Z'"),
    file_path: str = Field(description="Absolute path of the export file to write to"),
    format: str = Field(
        default="jsonl",
        description="Export format: 'json', 'jsonl', or 'csv'"
    ),
    include_comments: bool = Field(
        default=False,
        description="Whether to also export comments/replies associated with each post"
    ),
    include_metrics: bool = Field(
        default=True,
        description="Whether to export engagement metrics for each post"
    ),) -> bool:
    """
    Name:
        Export to file
    Description:
        Export social media content for a given account and time range directly into a local file.
    Args:
        platform: Target social media platform, e.g. 'twitter', 'facebook', 'instagram'.
        account_id: Unique identifier or handle of the social media account.
        since: Start datetime (inclusive) in ISO 8601 format.
        until: End datetime (exclusive) in ISO 8601 format.
        file_path: Absolute path of the export file to write to.
        format: Export format: 'json', 'jsonl', or 'csv'.
        include_comments: Whether to also export comments/replies associated with each post.
        include_metrics: Whether to export engagement metrics for each post.
    Returns:
        True on success, False on failure.
    """
    return export_to_file(platform, account_id, since, until, file_path, format, include_comments, include_metrics)
