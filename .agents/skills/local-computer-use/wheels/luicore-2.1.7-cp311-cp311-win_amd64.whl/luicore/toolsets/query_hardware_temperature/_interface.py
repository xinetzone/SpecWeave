# coding: utf-8
from .tools import get_all_temperatures


async def tool_get_all_temperatures() -> str:
    """
    Gets a snapshot of all available hardware temperatures.

    Args:
        None

    Returns:
        str: A JSON-formatted string containing available hardware temperatures,
            such as CPU, GPU, and motherboard.
    """
    return get_all_temperatures()
