# coding: utf-8
from .tools import get_drive_free_space, get_drive_total_space, list_logical_drives, get_drive_usage, get_all_drives_usage


async def tool_get_drive_free_space() -> list[dict]:
    """
    Gets the free space information for all logical drives.

    Args:
        None

    Returns:
        list[dict]: A list of dictionaries representing drive free space information.
    """
    return get_drive_free_space()

# async def tool_get_drive_total_space(drive: str = Field(description="Drive letter with colon, for example 'C:'"),) -> int:
#     """
#     Gets the total capacity (in bytes) of the specified drive.
#
#     Args:
#         drive (str): Drive letter with colon, for example "C:".
#
#     Returns:
#         int: Total capacity in bytes of the specified drive.
#     """
#     return get_drive_total_space(drive)
#
# async def tool_list_logical_drives() -> list[str]:
#     """
#     Lists all logical drive roots available on the current system.
#
#     Args:
#         None
#
#     Returns:
#         list[str]: A list of drive roots, for example ["C:", "D:", "E:"]. 
#     """
#     return list_logical_drives()
#
# async def tool_get_drive_usage(drive: str = Field(description="Drive letter with colon, for example 'C:'"),) -> dict:
#     """
#     Gets usage statistics for the specified drive, including total, used, and free space.
#
#     Args:
#         drive (str): Drive letter with colon, for example "C:".
#
#     Returns:
#         dict: A dictionary with keys:
#             - total (int): Total capacity in bytes.
#             - used (int): Used space in bytes.
#             - free (int): Free space in bytes.
#     """
#     return get_drive_usage(drive)
#
# async def tool_get_all_drives_usage() -> list[dict]:
#     """
#     Gets usage statistics for all logical drives, including total, used, and free space.
#
#     Args:
#         None
#
#     Returns:
#         list[dict]: A list of dictionaries, each containing:
#             - drive (str): Drive letter, for example "C:".
#             - total (int): Total capacity in bytes.
#             - used (int): Used space in bytes.
#             - free (int): Free space in bytes.
#     """
#     return get_all_drives_usage()
