# coding: utf-8
from .tools import open_registry_editor


async def tool_open_registry_editor() -> bool:
    """
    Opens the Windows Registry Editor.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return open_registry_editor()
