# coding: utf-8
from .tools import open_printer_setting


async def tool_open_printer_setting() -> bool:
    """
    Opens the Windows printer settings.
    User can view, add or manage printers and print queues from there.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return open_printer_setting()
