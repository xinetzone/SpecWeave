# coding: utf-8
from .tools import open_contrast_theme_settings


async def tool_open_contrast_theme_settings() -> bool:
    """
    Opens the Windows contrast theme settings.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return open_contrast_theme_settings()
