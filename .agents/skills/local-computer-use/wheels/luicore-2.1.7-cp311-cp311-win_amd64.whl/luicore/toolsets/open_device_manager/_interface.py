# coding: utf-8
from pydantic import Field
from .tools import open_device_manager


async def tool_open_device_manager() -> bool:
    """
    Opens the Windows Device Manager.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return open_device_manager()
