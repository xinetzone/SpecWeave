# coding: utf-8
from .tools import open_performance_monitor


async def tool_open_performance_monitor() -> bool:
    """
    Opens the Windows Performance Monitor.

    Args:
        None

    Returns:
        bool: True if successful, False otherwise.
    """
    return open_performance_monitor()
